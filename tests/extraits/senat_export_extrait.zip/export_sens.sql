--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;
COPY bur (burcod, burlib, burlic, burnumtri, burlil, burlibhon, burlicfem, burlibfem, burlilfem, burlicplu, burlibplu, burlilplu, burlibhonfem, burlibhonplu, syscredat, sysmajdat, burlicfemplu, burlibfemplu, burlilfemplu) FROM stdin;
AUCUNSEN	\N	Sénateur	5	Sénateur	\N	Sénateur	\N	Sénatrice	Sénateurs	\N	Sénateurs	\N	\N	\N	\N	Sénateurs	\N	Sénateurs
PDTSEN	Président du Sénat	Président	1	Président du Sénat	Président honoraire du Sénat	Présidente	Présidente du Sénat	Présidente du Sénat	Présidents	Présidents du Sénat	Présidents du Sénat	Présidente honoraire du Sénat	Présidents honoraires du Sénat	\N	\N	Présidentes	Présidentes du Sénat	Présidentes du Sénat
QUESTESEN	Questeur du Sénat	Questeur	3	Questeur du Sénat	Questeur honoraire du Sénat	Questeure	Questeure du Sénat	Questeure du Sénat	Questeurs	Questeurs du Sénat	Questeurs du Sénat	Questeure honoraire du Sénat	Questeurs honoraires du Sénat	\N	\N	Questeurs	Questeurs du Sénat	Questeures du Sénat
SECRETSEN	Secrétaire du Sénat	Secrétaire	4	Secrétaire du Sénat	Secrétaire honoraire du Sénat	Secrétaire	Secrétaire du Sénat	Secrétaire du Sénat	Secrétaires	Secrétaires du Sénat	Secrétaires du Sénat	Secrétaire honoraire du Sénat	Secrétaires honoraires du Sénat	\N	\N	Secrétaires	Secrétaires du Sénat	Secrétaires du Sénat
VICPDTSEN	Vice-président du Sénat	Vice-président	2	Vice-président du Sénat	Vice-président honoraire du Sénat	Vice-présidente	Vice-présidente du Sénat	Vice-présidente du Sénat	Vice-présidents	Vice-présidents du Sénat	Vice-présidents du Sénat	Vice-présidente honoraire du Sénat	Vice-présidents honoraires du Sénat	\N	\N	Vice-présidentes	Vice-présidentes du Sénat	Vice-présidentes du Sénat
\.

COPY com (typorgcod, orgcod, orgnumtri, orgdatcre, orgdatfin, orgnumtie, temvalcod, evelic, evelib, evelil, orgart, comlilmin, orgurlsim, orgurlcmp, comlibameli, comcodameli, divcod, syscredat, sysmajdat) FROM stdin;
CMP	2007CMP16	\N	2007-12-14 00:00:00	2007-12-18 00:00:00	\N	ANCIEN	\N	développement de la concurrence au service des consommateurs	\N	du	projet de loi pour le développement de la concurrence au service des consommateurs	\N	\N	\N	\N	999	\N	2016-09-15 16:40:06
CMP	2008CMP9	\N	2008-07-10 00:00:00	2008-07-17 00:00:00	\N	ANCIEN	\N	modernisation de l'économie	\N	du	projet de loi de modernisation de l'économie	\N	\N	\N	\N	999	\N	2016-09-15 16:40:05
COMSPE	ECONOMIE	1	2008-06-18 00:00:00	2008-07-23 00:00:00	\N	ANCIEN	Modernisation de l'économie	Commission spéciale sur la modernisation de l'économie	COMMISSION SPÉCIALE SUR LE PROJET DE LOI DE MODERNISATION DE L'ÉCONOMIE	de la	Commission spéciale sur le projet de loi de modernisation de l'économie	/commission/spec/LME/index.html	\N	Commission spéciale modernisation de l'économie	LME	999	\N	2014-04-07 11:23:22
CMP	2009CMP1	\N	2009-01-21 00:00:00	2009-01-28 00:00:00	\N	ANCIEN	\N	Communication audiovisuelle et service public de la télévisi	\N	du	projet de loi relatif à la communication audiovisuelle et au nouveau service public de la télévision	\N	\N	\N	\N	999	\N	2016-09-15 16:40:05
COM	AFCL	5	1899-12-31 00:00:00	\N	\N	ACTIF	AFCL	Culture	COMMISSION DE LA CULTURE, DE L'ÉDUCATION, DE LA COMMUNICATION ET DU SPORT	de la	commission de la culture, de l'éducation, de la communication et du sport	/commission/cult/index.html	\N	commission de la culture	CULT	151	\N	2024-01-18 00:00:00
COM	ECON	100	1900-01-01 00:00:00	2012-02-20 00:00:00	\N	ANCIEN	ECON	Économie	COMMISSION DE L'ÉCONOMIE, DU DÉVELOPPEMENT DURABLE ET DE L'AMÉNAGEMENT DU TERRITOIRE	de la 	commission de l'économie, du développement durable et de l'aménagement du territoire	/commission/eco/index.html	\N	commission de l'économie	ECON	152	\N	2013-11-27 14:35:33
COM	ETRD	2	1900-01-01 00:00:00	\N	\N	ACTIF	ETRD	Affaires étrangères	COMMISSION DES AFFAIRES ÉTRANGÈRES, DE LA DÉFENSE ET DES FORCES ARMÉES	de la 	commission des affaires étrangères, de la défense et des forces armées	/commission/etr/index.html	\N	commission des affaires étrangères	ETRD	153	\N	2013-11-27 14:35:32
COM	NEANT	10	1900-01-01 00:00:00	\N	\N	ACTIF	Aucune	\N	Aucune	d'	Aucune	\N	\N	Aucune	NEANT	999	\N	2024-11-25 11:32:28
COM	SOCI	3	1900-01-01 00:00:00	\N	\N	ACTIF	SOCI	Affaires sociales	COMMISSION DES AFFAIRES SOCIALES	de la 	commission des affaires sociales	/commission/soc/index.html 	\N	commission des affaires sociales	ASOC	154	\N	2013-11-27 14:35:33
COMSPE	SERVICE	1	2007-07-05 00:00:00	2007-08-02 00:00:00	\N	ANCIEN	Service minimum	Commission spéciale sur le service minimum	COMMISSION SPECIALE SUR LE PROJET DE LOI RELATIF AU SERVICE MINIMUM	de la	Commission spéciale sur le projet de loi relatif au service minimum	/commission/spec/servicepublic/index.html	\N	Commission spéciale	SPEC	999	\N	2014-04-07 11:23:22
CMP	2009CMP23	\N	2009-12-22 00:00:00	2016-07-01 00:00:00	\N	ANCIEN	\N	La Poste et activités postables	\N	du 	projet de loi relatif à l'entreprise publique La Poste et aux activités postales	\N	\N	\N	\N	999	\N	\N
CMP	2011CMP3	\N	2011-02-10 00:00:00	2016-07-01 00:00:00	\N	ANCIEN	\N	législation au droit de lUnion européenne en matière de santé, de travail et de communications électroniques	\N	du 	projet de loi portant diverses dispositions dadaptation de la législation au droit de lUnion européenne en matière de santé, de travail et de communications électroniques 	\N	\N	\N	\N	999	\N	\N
CMP	20030515N2	\N	2003-05-15 00:00:00	2003-05-22 00:00:00	\N	ANCIEN	\N	Urbanisme, habitat et construction	\N	du	projet de loi portant diverses dispositions relatives à l'urbanisme, à l'habitat et à la construction	\N	\N	\N	\N	999	\N	2016-09-15 16:40:06
COMSPE	INITIATIVE	2	2003-02-12 00:00:00	2003-07-21 00:00:00	\N	ANCIEN	INITIATIVE ÉCONOMIQUE	COMMISSION SPÉCIALE "INITIATIVE ÉCONOMIQUE"	COMMISSION SPÉCIALE CHARGÉE D'EXAMINER LE PROJET DE LOI POUR L'INITIATIVE ÉCONOMIQUE	de la	commission spéciale chargée d'examiner le projet de loi pour l'initiative économique	\N	\N	Commission spéciale	INIT	999	\N	2014-02-19 17:47:45
CMP	20030715N6	\N	2003-07-15 00:00:00	2003-07-22 00:00:00	\N	ANCIEN	\N	prévention des risques technologiques et naturels	\N	du	projet de loi relatif à la prévention des risques technologiques et naturels et à la réparation des dommages	\N	\N	\N	\N	999	\N	2016-09-15 16:40:06
MISINFCOM	FORMATION	\N	2007-01-10 00:00:00	2007-07-11 00:00:00	\N	ANCIEN	MCI FORMATION	Mission commune d'information "Formation professionnelle"	MISSION COMMUNE D'INFORMATION SUR LE FONCTIONNEMENT DES DISPOSITIFS DE FORMATION PROFESSIONNELLE	de la 	Mission commune d'information sur le fonctionnement des dispositifs de formation professionnelle	/commission/missions/Formation/index.html	\N	Mission commune d'information "Formation professionnelle"	\N	999	\N	2015-01-14 10:41:26
CMP	2007CMP3	\N	2007-02-01 00:00:00	2007-02-13 00:00:00	\N	ANCIEN	\N	modernisation de la diffusion audiovisuelle et à la télévisi	\N	du	projet de loi relatif à la modernisation de la diffusion audiovisuelle et à la télévision du futur	\N	\N	\N	\N	999	\N	2016-09-15 16:40:06
MISCOM	COLLECTIVITE	0	2008-10-15 00:00:00	2009-06-30 00:00:00	\N	ANCIEN	Mission collectivités	Mission temporaire collectivités territoriales	MISSION TEMPORAIRE SUR L'ORGANISATION ET L'EVOLUTION DES COLLECTIVITÉS TERRITORIALES	de la	Mission temporaire sur l'organisation et l'évolution des collectivités territoriales	/mission_temporaire_coll_ter/index.html	\N	Mission temporaire collectivités territoriales	\N	999	\N	2014-04-07 15:43:10
MISINFCOM	XYNTHIA	\N	2010-03-30 00:00:00	2010-07-09 00:00:00	\N	ANCIEN	Tempête Xynthia	Mission commune d'information sur les conséquences de la tempête Xynthia	MISSION COMMUNE D'INFORMATION SUR LES CONSÉQUENCES DE LA TEMPÊTE XYNTHIA	de la	Mission commune d'information sur les conséquences de la tempête Xynthia	/commission/missions/xynthia/index.html	\N	Mission commune d'information sur les conséquences de la tempête Xynthia	\N	999	\N	2014-04-07 15:43:10
CMP	2009CMP6	\N	2009-04-02 00:00:00	2009-04-07 00:00:00	\N	ANCIEN	\N	diffusion et  protection de la création sur internet	\N	du	projet de loi favorisant la diffusion et la protection de la création sur internet	\N	\N	\N	\N	999	\N	2016-09-15 16:40:05
MISINFCOM	DECE	\N	2013-04-23 00:00:00	2013-10-09 00:00:00	\N	ANCIEN	MCI Organisation décentralisée 	Mission commune d'information sur l'avenir de l'organisation décentralisée de la République	MISSION COMMUNE D'INFORMATION SUR L'AVENIR DE L'ORGANISATION DÉCENTRALISÉE DE LA RÉPUBLIQUE	de la	Mission commune d'information sur l'avenir de l'organisation décentralisée de la République	/commission/missions/organisation_decentralisee_de_la_republique/index.html	\N	Mission commune d'information sur l'avenir de l'organisation décentralisée de la République	\N	999	\N	2014-04-14 14:34:35
COM	CAE	1	2012-02-21 00:00:00	\N	\N	ACTIF	CAE	Affaires économiques	COMMISSION DES AFFAIRES ÉCONOMIQUES	de la 	commission des affaires économiques	/commission/affaires_economiques/index.html	\N	commission des affaires économiques	AFFECO	152	\N	2026-10-06 17:33:13
MISINFCOM	GOUVERNANCE	1	2013-11-19 00:00:00	2014-09-30 00:00:00	\N	ANCIEN	MCI sur la gouvernance de l'internet	Mission commune d'information sur la gouvernance de l'internet	MISSION COMMUNE D'INFORMATION SUR LE NOUVEAU RÔLE ET LA NOUVELLE STRATÉGIE POUR L'UNION EUROPÉENNE DANS LA GOUVERNANCE DE L'INTERNET	de la 	Mission commune d'information sur le nouveau rôle et la nouvelle stratégie pour l'Union européenne dans la gouvernance de l'internet	/commission/missions/nouveau_role_et_nouvelle_strategie_pour_lunion_europeenne_dans_la_gouvernance_mondiale_de_linternet/index.html	\N	Mission commune d'information sur le nouveau rôle et la nouvelle stratégie pour l'UE dans la gouvernance de l'internet	\N	999	2013-11-19 18:29:05	2015-01-14 10:47:51
COMSPE	REGIONS	8	2014-06-18 00:00:00	2015-01-17 00:00:00	\N	ANCIEN	CS Délimitation des régions	Commission spéciale Délimitation des régions, élections régionales et départementales et calendrier électoral	COMMISSION SPÉCIALE CHARGÉE D'EXAMINER LE PROJET DE LOI RELATIF À LA DÉLIMITATION DES RÉGIONS, AUX ÉLECTIONS RÉGIONALES ET DÉPARTEMENTALES ET MODIFIANT LE CALENDRIER ÉLECTORAL	de la	Commission spéciale chargée d'examiner le projet de loi relatif à la délimitation des régions, aux élections régionales et départementales et modifiant le calendrier électoral	/commission/spec/delimitation_des_regions/index.html	\N	Commission spéciale Délimitation des régions, élections régionales et départementales et calendrier électoral	REGIONS	999	2014-06-18 21:46:50	2015-04-09 17:09:45
MISINFCOM	TURQUIE	999	2016-04-27 00:00:00	2016-10-14 00:00:00	\N	ANCIEN	MI Accord UE/Turquie	Mission d'information sur l'accord de mars 2016 entre l'Union européenne et la Turquie relatif à la crise des réfugiés	Mission d'information sur la position de la France à l'égard de l'accord de mars 2016 entre l'Union européenne et la Turquie relatif à la crise des réfugiés et sur les conditions de mise en oeuvre de cet accord	de la	mission d'information sur la position de la France à l'égard de l'accord de mars 2016 entre l'Union européenne et la Turquie relatif à la crise des réfugiés et sur les conditions de mise en oeuvre de cet accord	/commission/missions/accord_ue_turquie/index.html	\N	mission d'information sur l'accord UE/Turquie relatif à la crise des réfugiés	TURQUIE	999	2016-04-27 15:03:19	2017-06-12 11:08:26
CMP	2015CMP19	\N	2015-09-08 00:00:00	2016-07-01 00:00:00	\N	ANCIEN	\N	dividende numérique et  poursuite de la modernisation de la télévision numérique terrestre	\N	de la 	proposition de loi relative au deuxième dividende numérique et à la poursuite de la modernisation de la télévision numérique terrestre 	\N	\N	\N	\N	999	\N	\N
COMSPE	CITOYENNETE	999	2016-06-22 00:00:00	2016-07-07 00:00:00	\N	ANCIEN	GT Egalité et citoyenneté	Groupe de travail préfigurant commission spéciale Egalité et citoyenneté	GT PREFIGURANT COMMISSION SPECIALE EGALITE ET CITOYENNETE	de la	groupe de travail préfigurant commission spéciale "égalité et citoyenneté"	/commission/nouv/index.html	\N	Groupe de travail préfigurant commission spéciale Egalité et citoyenneté	PLEC	999	2016-06-22 16:05:02	2017-03-23 10:41:04
COMENQ	CHUTE	999	2018-02-07 00:00:00	2018-07-07 00:00:00	\N	ANCIEN	CE Moyens de l'Etat après chute Etat islamique	CE Moyens de l'Etat après chute Etat islamique	COMMISSION D'ENQUÊTE SUR L'ORGANISATION ET LES MOYENS DES SERVICES DE L'ETAT POUR FAIRE FACE À L'ÉVOLUTION DE LA MENACE TERRORISTE APRÈS LA CHUTE DE L'ETAT ISLAMIQUE	de la	Commission d'enquête sur l'organisation et les moyens des services de l'Etat pour faire face à l'évolution de la menace terroriste après la chute de l'Etat islamique	/commission/nouv/index.html	\N	CE Moyens de l'Etat après chute Etat islamique	\N	999	2018-02-06 16:26:47	2018-02-16 12:03:28
COMSPE	EGALITE	999	2016-07-07 00:00:00	2017-06-12 00:00:00	\N	ANCIEN	CS Egalité et citoyenneté	Commission spéciale chargée d'examiner le projet de loi « Egalité et citoyenneté »	COMMISSION SPÉCIALE CHARGÉE D¿EXAMINER LE PROJET DE LOI « ÉGALITÉ ET CITOYENNETÉ »	de la	commission spéciale chargée d'examiner le projet de loi « Égalité et citoyenneté »	/commission/spec/egalite_et_citoyennete/index.html	\N	Commission spéciale chargée d'examiner le projet de loi « Egalité et citoyenneté »	PLEC	999	2016-07-07 17:19:19	2017-06-12 11:07:18
CMP	LPM	999	2018-06-19 00:00:00	2018-06-20 00:00:00	\N	ANCIEN	\N	projet de loi relatif à la programmation militaire pour les années 2019-2025	\N	du	projet de loi relatif à la programmation militaire pour les années 2019-2025 et portant diverses dispositions intéressant la défense	/commission/nouv/index.html	\N	\N	LPM	999	\N	\N
CMP	INEG	999	2021-06-24 00:00:00	2021-06-25 00:00:00	\N	ANCIEN	INEG	PJL de programmation développement solidaire et lutte contre les inégalités mondiales	INEG	du	projet de loi de programmation relatif au développement solidaire et à la lutte contre les inégalités mondiales	/commission/nouv/index.html	\N	INEG	INEG	999	\N	\N
CMP	IMMI	999	2023-12-18 00:00:00	2023-12-19 00:00:00	\N	ANCIEN	IMMI	PJL Immigration	IMMI	du	projet de loi pour contrôler l'immigration, améliorer l'intégration	/commission/nouv/index.html	\N	IMMI	IMMI	999	\N	\N
COMSPE	CYBE	999	2024-06-05 00:00:00	\N	\N	ACTIF	CS Cybersécurité	CS Cybersécurité	Projet de loi relatif à la résilience des infrastructures critiques et au renforcement de la cybersécurité	de la	projet de loi relatif à la résilience des infrastructures critiques et au renforcement de la cybersécurité	\N	\N	CS Cybersécurité	CYBE	999	\N	2026-10-21 11:31:34
CMP	LPMD	\N	2026-06-22 00:00:00	\N	\N	ACTIF	PJL Actualisation LPM 2024-2030	PJL Actualisation LPM 2024-2030	Projet de loi actualisant la programmation militaire pour les années 2024 à 2030 et portant diverses dispositions intéressant la défense	du	projet de loi actualisant la programmation militaire pour les années 2024 à 2030 et portant diverses dispositions intéressant la défense	\N	\N	LPMD	LPMD	999	2026-06-22 15:06:40	2026-07-02 10:11:25
\.

COPY dpt (dptnum, dptcod, dptlib, dptnbrsen, dptmodscrsen, dptser, regcod, dptnumtri, dptlic, dptart, dptlibtri, temvalcod, evelic, evelib, evelil, dptser2004, dptcmt, dptdatdeb, dptdatfin, dpturlcmp, syscredat, sysmajdat) FROM stdin;
580	58	Nièvre	2	SM	B	24	580	Nièvre	de la 	Nièvre	ACTIF	Nièvre	Nièvre	Nièvre	1	\N	1959-04-28 00:00:00	\N	http://www.cg58.fr/	\N	\N
660	66	Pyrénées-Orientales	2	SM	B	29	660	Pyrénées-Orientales	des 	Pyrénées Orientales	ACTIF	Pyrénées-Oriental.	Pyrénées-Orientales	Pyrénées-Orientales	1	\N	1959-04-28 00:00:00	\N	http://www.cg66.fr/	\N	\N
770	77	Seine-et-Marne	6	RP	C	10	770	Seine-et-Marne	de la 	Seine-Marne	ACTIF	Seine-et-Marne	Seine-et-Marne	Seine-et-Marne	1	\N	1959-04-28 00:00:00	\N	http://www.cg77.fr/	\N	\N
820	82	Tarn-et-Garonne	2	SM	C	29	820	Tarn-et-Garonne	du 	Tarn-et-Garonne	ACTIF	Tarn-et-Garonne	Tarn-et-Garonne	Tarn-et-Garonne	2	\N	1959-04-28 00:00:00	\N	http://www.cg82.fr/	\N	\N
890	89	Yonne	2	SM	C	24	890	Yonne	de l'	Yonne	ACTIF	Yonne	Yonne	Yonne	2	\N	1959-04-28 00:00:00	\N	http://www.lyonne.com/	\N	\N
973	973	Guyane	2	SM	A	51	972	Guyane	de la 	Guyane	ACTIF	Guyane	Guyane	Guyane	2	\N	1959-04-28 00:00:00	\N	\N	\N	\N
974	974	La Réunion	4	RP	B	53	974	La Réunion	de 	La Réunion	ACTIF	La Réunion	La Réunion	La Réunion	1	\N	1959-04-28 00:00:00	\N	http://www.cg974.fr/	\N	\N
983	987	Polynésie française	2	SM	A	61	983	Polynésie française	de la 	Polynésie française	ACTIF	Polynésie française	Polynésie française	Polynésie française	2	\N	1959-04-28 00:00:00	\N	\N	\N	\N
995	975	Saint-Pierre-et-Miquelon	1	SM	C	71	981	Saint-Pierre-et-Miquelon	de 	Saint-Pierre-et-Miquelon	ACTIF	Saint-Pierre-Miquelon	Saint-Pierre-et-Miquelon	Saint-Pierre-et-Miquelon	1	\N	1959-04-28 00:00:00	\N	http://www.cg975.fr	\N	\N
998	998	Français établis hors de France (Série B)	\N	RP	B	90	999	Français établis hors de France	représentant les 	Français établis hors de France	ANCIEN	Hors de France B	Français établis hors de France (Série B)	Français établis hors de France (Série B)	1	\N	1959-04-28 00:00:00	2010-09-30 00:00:00	\N	\N	\N
260	26	Drôme	3	RP	A	30	260	Drôme	de la 	Drôme	ACTIF	Drôme	Drôme	Drôme	2	\N	1959-04-28 00:00:00	\N	http://www.cg26.fr/	\N	\N
335	92	Hauts-de-Seine	7	RP	C	10	920	Hauts-de-Seine	des 	Hauts-de-Seine	ACTIF	Hauts-de-Seine	Hauts-de-Seine	Hauts-de-Seine	1	\N	1968-01-01 00:00:00	\N	http://www.cg92.fr/	\N	\N
530	53	Mayenne	2	SM	B	18	530	Mayenne	de la 	Mayenne	ACTIF	Mayenne	Mayenne	Mayenne	1	\N	1959-04-28 00:00:00	\N	http://www.cg53.fr/	\N	\N
650	65	Hautes-Pyrénées	2	SM	B	29	650	Hautes-Pyrénées	des 	Pyrénées Hautes	ACTIF	Hautes-Pyrénées	Hautes-Pyrénées	Hautes-Pyrénées	1	\N	1959-04-28 00:00:00	\N	http://www.cg65.fr/	\N	\N
800	80	Somme	3	RP	C	26	800	Somme	de la 	Somme	ACTIF	Somme	Somme	Somme	2	\N	1959-04-28 00:00:00	\N	http://www.cg80.fr/	\N	\N
50	05	Hautes-Alpes	1	SM	A	21	50	Hautes-Alpes	des 	Alpes Hautes	ACTIF	Hautes-Alpes	Hautes-Alpes	Hautes-Alpes	2	\N	1959-04-28 00:00:00	\N	http://www.cg05.fr	\N	\N
310	31	Haute-Garonne	5	RP	A	29	310	Haute-Garonne	de la 	Garonne Haute	ACTIF	Haute-Garonne	Haute-Garonne	Haute-Garonne	2	\N	1959-04-28 00:00:00	\N	http://www.cg31.fr/	\N	\N
640	64	Pyrénées-Atlantiques	3	RP	B	28	640	Pyrénées-Atlantiques	des 	Pyrénées Atlantiques	ACTIF	Pyrénées-Atlantiq.	Pyrénées-Atlantiques	Pyrénées-Atlantiques	1	\N	1969-10-10 00:00:00	\N	http://www.cg64.fr/	\N	\N
125	90	Territoire de Belfort	1	SM	A	24	900	Territoire de Belfort	du 	Belfort	ACTIF	Belfort	Territoire de Belfort	Territoire de Belfort	2	\N	1959-04-28 00:00:00	\N	http://www.cg90.fr/	\N	\N
200	2A	Corse-du-Sud	1	SM	A	8	204	Corse-du-Sud	de la 	Corse duSud	ACTIF	Corse-du-Sud	Corse-du-Sud	Corse-du-Sud	2	\N	1975-05-15 00:00:00	\N	\N	\N	\N
9999	9999	indéterminé	\N	NEANT	X	93	9999	indéterminé	\N	indéterminé	ANCIEN	indéterminé	indéterminé	indéterminé	\N	\N	1959-04-28 00:00:00	1959-04-28 00:00:00	\N	\N	\N
1000	44	Loire-Inférieure	\N	NEANT	B	18	445	Loire-Inférieure	de la	Loire-Inférieure	ANCIEN	Loire-Inférieure	Loire-Inférieure av. mar 1957	Loire-Inférieure devenue Loire-Atlantique (09/03/1957)	\N	\N	\N	1957-03-09 00:00:00	http://www.cg44.fr/	\N	\N
1004	64	Basses-Pyrénées	\N	NEANT	B	2	645	Basses-Pyrénées	des 	Pyrénées Basses	ANCIEN	Basses-Pyrénées	Basses-Pyrénées av. oct 1969	Basses-Pyrénées devenues Pyrénées-Atlantiques (10/10/1969)	\N	\N	1959-04-28 00:00:00	1969-10-10 00:00:00	http://www.cg64.fr/	\N	\N
1002	20	Corse	\N	NEANT	A	8	200	Corse	de la	Corse	ANCIEN	Corse	Corse av. mai 1975	Corse devenue Haute Corse et Corse-du-Sud (15/05/1975)	\N	\N	1959-04-28 00:00:00	1975-05-15 00:00:00	\N	\N	\N
1029	75	Seine	\N	NEANT	C	10	750	Seine	de la 	Seine	ANCIEN	Seine	Seine av. jan 1968	Seine devenue Paris, Hauts-de-Seine, Seine-Saint-Denis,Val-de-Marne (01/01/1968)	\N	\N	1959-04-28 00:00:00	1968-01-01 00:00:00	\N	\N	\N
1032	76	Seine-Inférieure	\N	NEANT	C	17	755	Seine-Inférieure	de la 	Seine-Inférieure	ANCIEN	Seine-Inférieure	Seine-Inférieure av. jan 1955	Seine-Inférieure devenue Seine-Maritime (18/01/1955)	\N	\N	\N	1955-01-18 00:00:00	http://www.cg76.fr/	\N	\N
1011	04	Basses-Alpes	\N	NEANT	A	21	45	Basses-Alpes	des 	Alpes Basses	ANCIEN	Basses-Alpes	Basses-Alpes av. avr 1969	Basses-Alpes devenues Alpes de Haute-Provence (13/04/1969)	\N	\N	1959-04-28 00:00:00	1969-04-13 00:00:00	http://www.cg04.fr/	\N	\N
1020	78	Seine-et-Oise	\N	NEANT	C	10	780	Seine-et-Oise	de la	Seine-Oise	ANCIEN	Seine-et-Oise	Seine-et-Oise av. jan 1968	Seine-et-Oise devenue Hauts-de-Seine, Val-de-Marne, Seine-Saint-Denis, Val d'Oise, Yvelines, Essonne (01/01/1968)	\N	\N	1959-04-28 00:00:00	1968-01-01 00:00:00	http://www.yvelines.fr	\N	\N
1047	1047	Territoire des afars et des Issas	\N	NEANT	X	72	997	Territoire des afars et des Issas	du 	Territoire des afar et des Issas	ANCIEN	Territoire des afars et des Issas	Territoire des afars et des Issas (ap. mars 1977)	Territoire des afar et des issas (après le 19 mars 1977)	\N	\N	1967-03-19 00:00:00	1977-03-19 00:00:00	\N	\N	\N
790	79	Deux-Sèvres	2	SM	C	28	790	Deux-Sèvres	des 	Sèvres	ACTIF	Deux-Sèvres	Deux-Sèvres	Deux-Sèvres	2	\N	1959-04-28 00:00:00	\N	\N	\N	\N
100	10	Aube	2	SM	A	27	100	Aube	de l'	Aube	ACTIF	Aube	Aube	Aube	2	\N	1959-04-28 00:00:00	\N	http://www.cg-aube.com/	\N	\N
340	34	Hérault	4	RP	A	29	340	Hérault	de l'	Hérault	ACTIF	Hérault	Hérault	Hérault	2	\N	1959-04-28 00:00:00	\N	http://www.cg34.fr/	\N	\N
824	94	Val-de-Marne	6	RP	C	10	940	Val-de-Marne	du 	Val-de-Marne	ACTIF	Val-de-Marne	Val-de-Marne	Val-de-Marne	1	\N	1968-01-01 00:00:00	\N	\N	\N	\N
270	27	Eure	3	RP	A	25	270	Eure	de l'	Eure	ACTIF	Eure	Eure	Eure	2	\N	1959-04-28 00:00:00	\N	http://www.cg27.fr/	\N	\N
710	71	Saône-et-Loire	3	RP	C	24	710	Saône-et-Loire	de la 	Saône-et-Loire	ACTIF	Saône-et-Loire	Saône-et-Loire	Saône-et-Loire	2	\N	1959-04-28 00:00:00	\N	http://www.cg71.com	\N	\N
205	2B	Haute-Corse	1	SM	A	8	205	Haute-Corse	de la 	Corse Haute	ACTIF	Haute-Corse	Haute-Corse	Haute-Corse	2	\N	1975-05-15 00:00:00	\N	\N	\N	\N
720	72	Sarthe	3	RP	C	18	720	Sarthe	de la 	Sarthe	ACTIF	Sarthe	Sarthe	Sarthe	2	\N	1959-04-28 00:00:00	\N	http://www.cg72.fr/	\N	\N
860	86	Vienne	2	SM	C	28	860	Vienne	de la 	Vienne	ACTIF	Vienne	Vienne	Vienne	2	\N	1959-04-28 00:00:00	\N	http://www.cg86.fr/	\N	\N
220	22	Côtes-d'Armor	3	RP	A	5	220	Côtes-d'Armor	des 	Côtes d'Armor	ACTIF	Côtes-d'Armor	Côtes-d'Armor	Côtes-d'Armor	2	\N	1990-02-27 00:00:00	\N	http://www.cg22.fr/	\N	\N
999	999	Français établis hors de France (Série C)	\N	RP	C	90	999	Français établis hors de France	représentant les 	Français établis hors de France	ANCIEN	Hors de France C	Français établis hors de France (Série C)	Français établis hors de France (Série C)	2	\N	1959-04-28 00:00:00	2004-09-30 00:00:00	\N	\N	\N
9715	978	Saint-Martin	1	SM	A	55	978	Saint-Martin	de 	Saintmartin	ACTIF	St-Martin	Saint-Martin	Saint-Martin	2	\N	2008-10-01 00:00:00	\N	\N	\N	\N
1051	998	Français établis hors de France (Série C 1)	\N	RP	C	90	999	Français établis hors de France	représentant les 	Français établis hors de France	ANCIEN	Hors de France C 1	Français établis hors de France (Série C 1)	Français établis hors de France (Série C 1)	1	\N	2004-10-01 00:00:00	2010-09-30 00:00:00	\N	\N	\N
1052	997	Français établis hors de France (Série C 2)	\N	RP	C	90	999	Français établis hors de France	représentant les 	Français établis hors de France	ANCIEN	Hors de France C 2	Français établis hors de France (Série C 2)	Français établis hors de France (Série C 2)	2	\N	2004-10-01 00:00:00	2014-09-30 00:00:00	\N	\N	\N
9713	977	Saint-Barthélemy	1	SM	A	54	977	Saint-Barthélemy	de 	Saintbarthélemy	ACTIF	St-Barthélemy	Saint-Barthélemy	Saint-Barthélemy	2	\N	2008-10-01 00:00:00	\N	\N	\N	\N
250	25	Doubs	3	RP	A	24	250	Doubs	du 	Doubs	ACTIF	Doubs	Doubs	Doubs	2	\N	1959-04-28 00:00:00	\N	Http://www.cg25.fr/ 	\N	\N
80	08	Ardennes	2	SM	A	27	80	Ardennes	des 	Ardennes	ACTIF	Ardennes	Ardennes	Ardennes	2	\N	1959-04-28 00:00:00	\N	\N	\N	\N
630	63	Puy-de-Dôme	3	RP	B	30	630	Puy-de-Dôme	du 	Puy-de-Dôme	ACTIF	Puy-de-Dôme	Puy-de-Dôme	Puy-de-Dôme	1	\N	1959-04-28 00:00:00	\N	http://www.cg63.fr/	\N	\N
350	35	Ille-et-Vilaine	4	RP	A	5	350	Ille-et-Vilaine	d'	Ille-et-Vilaine	ACTIF	Ille-et-Vilaine	Ille-et-Vilaine	Ille-et-Vilaine	2	\N	1959-04-28 00:00:00	\N	http://www.cg35.fr/	\N	\N
1026	22	Côtes-du-Nord	\N	NEANT	A	5	225	Côtes-du-Nord	des 	Cotes du Nord	ANCIEN	Côtes du Nord	Côtes du Nord av. fev 1990	Côtes du Nord devenues Côtes d'Armor (27/02/1990)	\N	\N	1959-04-28 00:00:00	1990-02-27 00:00:00	http://www.cg22.fr/	\N	\N
740	74	Haute-Savoie	3	RP	C	30	740	Haute-Savoie	de la 	Savoie Haute	ACTIF	Haute-Savoie	Haute-Savoie	Haute-Savoie	2	\N	1959-04-28 00:00:00	\N	http://www.cg74.fr/	\N	\N
70	07	Ardèche	2	SM	A	30	70	Ardèche	de l'	Ardèche	ACTIF	Ardèche	Ardèche	Ardèche	2	\N	1959-04-28 00:00:00	\N	http://www.cg07.fr/	\N	\N
240	24	Dordogne	2	SM	A	28	240	Dordogne	de la 	Dordogne	ACTIF	Dordogne	Dordogne	Dordogne	2	\N	1959-04-28 00:00:00	\N	http://www.cg24.fr/	\N	\N
390	39	Jura	2	SM	B	24	390	Jura	du 	Jura	ACTIF	Jura	Jura	Jura	1	\N	1959-04-28 00:00:00	\N	http://www.cg39.fr/	\N	\N
610	61	Orne	2	SM	B	25	610	Orne	de l'	Orne	ACTIF	Orne	Orne	Orne	1	\N	1959-04-28 00:00:00	\N	http://www.cg61.fr/	\N	\N
60	06	Alpes-Maritimes	5	RP	A	21	60	Alpes-Maritimes	des 	Alpes Maritimes	ACTIF	Alpes-Maritimes	Alpes-Maritimes	Alpes-Maritimes	2	\N	1959-04-28 00:00:00	\N	http://www.cg06.fr/	\N	\N
90	09	Ariège	1	SM	A	29	90	Ariège	de l'	Ariège	ACTIF	Ariège	Ariège	Ariège	2	\N	1959-04-28 00:00:00	\N	\N	\N	\N
110	11	Aude	2	SM	A	29	110	Aude	de l'	Aude	ACTIF	Aude	Aude	Aude	2	\N	1959-04-28 00:00:00	\N	http://www.cg11.fr/	\N	\N
150	15	Cantal	2	SM	A	30	150	Cantal	du 	Cantal	ACTIF	Cantal	Cantal	Cantal	2	\N	1959-04-28 00:00:00	\N	\N	\N	\N
160	16	Charente	2	SM	A	28	160	Charente	de la 	Charente	ACTIF	Charente	Charente	Charente	2	\N	1959-04-28 00:00:00	\N	\N	\N	\N
180	18	Cher	2	SM	A	23	180	Cher	du 	Cher	ACTIF	Cher	Cher	Cher	2	\N	1959-04-28 00:00:00	\N	http://www.cg18.fr/	\N	\N
190	19	Corrèze	2	SM	A	28	190	Corrèze	de la 	Corrèze	ACTIF	Corrèze	Corrèze	Corrèze	2	\N	1959-04-28 00:00:00	\N	http://www.cg19.fr/	\N	\N
210	21	Côte-d'Or	3	RP	A	24	210	Côte-d'Or	de la 	Côte-d'Or	ACTIF	Côte-d'Or	Côte-d'Or	Côte-d'Or	2	\N	1959-04-28 00:00:00	\N	http://www.cg21.fr/	\N	\N
230	23	Creuse	2	SM	A	28	230	Creuse	de la 	Creuse	ACTIF	Creuse	Creuse	Creuse	2	\N	1959-04-28 00:00:00	\N	http://www.cg23.fr/	\N	\N
265	91	Essonne	5	RP	C	10	910	Essonne	de l'	Essonne	ACTIF	Essonne	Essonne	Essonne	1	\N	1968-01-01 00:00:00	\N	http://www.essonne.fr	\N	\N
300	30	Gard	3	RP	A	29	300	Gard	du 	Gard	ACTIF	Gard	Gard	Gard	2	\N	1959-04-28 00:00:00	\N	http://www.cg30.fr/	\N	\N
320	32	Gers	2	SM	A	29	320	Gers	du 	Gers	ACTIF	Gers	Gers	Gers	2	\N	1959-04-28 00:00:00	\N	http://www.cg32.fr/	\N	\N
330	33	Gironde	6	RP	A	28	330	Gironde	de la 	Gironde	ACTIF	Gironde	Gironde	Gironde	2	\N	1959-04-28 00:00:00	\N	http://www.cg33.fr/	\N	\N
360	36	Indre	2	SM	A	23	360	Indre	de l'	Indre	ACTIF	Indre	Indre	Indre	2	\N	1959-04-28 00:00:00	\N	http://www.cg36.fr/	\N	\N
400	40	Landes	2	SM	B	28	400	Landes	des 	Landes	ACTIF	Landes	Landes	Landes	1	\N	1959-04-28 00:00:00	\N	http://www.cg40.fr/	\N	\N
420	42	Loire	4	RP	B	30	420	Loire	de la 	Loire	ACTIF	Loire	Loire	Loire	1	\N	1959-04-28 00:00:00	\N	http://www.cg42.fr/	\N	\N
450	45	Loiret	3	RP	B	23	450	Loiret	du 	Loiret	ACTIF	Loiret	Loiret	Loiret	1	\N	1959-04-28 00:00:00	\N	http://www.loiret.com/	\N	\N
460	46	Lot	2	SM	B	29	460	Lot	du 	Lot	ACTIF	Lot	Lot	Lot	1	\N	1959-04-28 00:00:00	\N	http://www.cg46.fr/	\N	\N
480	48	Lozère	1	SM	B	29	480	Lozère	de la 	Lozère	ACTIF	Lozère	Lozère	Lozère	1	\N	1959-04-28 00:00:00	\N	\N	\N	\N
997	997	Français établis hors de France (Série A)	\N	RP	A	90	999	Français établis hors de France	représentant les 	Français établis hors de France	ANCIEN	Hors de France A	Français établis hors de France (Série A)	Français établis hors de France (Série A)	2	\N	1959-04-28 00:00:00	2014-09-30 00:00:00	\N	\N	\N
20	02	Aisne	3	RP	A	26	20	Aisne	de l'	Aisne	ACTIF	Aisne	Aisne	Aisne	2	\N	1959-04-28 00:00:00	\N	http://www.cg02.fr/	\N	\N
290	29	Finistère	4	RP	A	5	290	Finistère	du 	Finistère	ACTIF	Finistère	Finistère	Finistère	2	\N	1959-04-28 00:00:00	\N	http://www.cg29.fr/	\N	\N
370	37	Indre-et-Loire	3	RP	B	23	370	Indre-et-Loire	d'	Indre-et-Loire	ACTIF	Indre-et-Loire	Indre-et-Loire	Indre-et-Loire	1	\N	1959-04-28 00:00:00	\N	http://www.cg37.fr/	\N	\N
430	43	Haute-Loire	2	SM	B	30	430	Haute-Loire	de la 	Loire Haute	ACTIF	Haute-Loire	Haute-Loire	Haute-Loire	1	\N	1959-04-28 00:00:00	\N	http://www.cg43.fr/	\N	\N
560	56	Morbihan	3	RP	B	5	560	Morbihan	du 	Morbihan	ACTIF	Morbihan	Morbihan	Morbihan	1	\N	1959-04-28 00:00:00	\N	http://www.cg56.fr/	\N	\N
620	62	Pas-de-Calais	7	RP	B	26	620	Pas-de-Calais	du 	Pas-de-Calais	ACTIF	Pas-de-Calais	Pas-de-Calais	Pas-de-Calais	1	\N	1959-04-28 00:00:00	\N	http://www.cg62.fr/	\N	\N
690	69	Rhône	7	RP	C	30	690	Rhône	du 	Rhône	ACTIF	Rhône	Rhône	Rhône	2	\N	1959-04-28 00:00:00	\N	http://www.rhone.fr	\N	\N
760	76	Seine-Maritime	6	RP	C	25	760	Seine-Maritime	de la 	Seine-Maritime	ACTIF	Seine-Maritime	Seine-Maritime	Seine-Maritime	2	\N	1955-01-18 00:00:00	\N	http://www.cg76.fr/	\N	\N
120	12	Aveyron	2	SM	A	29	120	Aveyron	de l'	Aveyron	ACTIF	Aveyron	Aveyron	Aveyron	2	\N	1959-04-28 00:00:00	\N	http://www.cg12.fr/	\N	\N
140	14	Calvados	3	RP	A	25	140	Calvados	du 	Calvados	ACTIF	Calvados	Calvados	Calvados	2	\N	1959-04-28 00:00:00	\N	http://www.calvados.fr	\N	\N
870	87	Haute-Vienne	2	SM	C	28	870	Haute-Vienne	de la 	Vienne Haute	ACTIF	Haute-Vienne	Haute-Vienne	Haute-Vienne	2	\N	1959-04-28 00:00:00	\N	http://www.cg87.fr/	\N	\N
410	41	Loir-et-Cher	2	SM	B	23	410	Loir-et-Cher	de 	Loir et Cher	ACTIF	Loir-et-Cher	Loir-et-Cher	Loir-et-Cher	1	\N	1959-04-28 00:00:00	\N	\N	\N	\N
1053	998	Français établis hors de France (Série 1)	6	RP	X	90	999	Français établis hors de France	représentant les 	Français établis hors de France	ACTIF	Hors de France (Série 1)	Français établis hors de France (Série 1)	Français établis hors de France (Série 1)	1	\N	2011-10-01 00:00:00	\N	\N	\N	\N
1054	997	Français établis hors de France (Série 2)	6	RP	X	90	999	Français établis hors de France	représentant les 	Français établis hors de France	ACTIF	Hors de France (Série 2)	Français établis hors de France (Série 2)	Français établis hors de France (Série 2)	2	\N	2014-10-01 00:00:00	\N	\N	\N	\N
1036	1030	Oran	1	NEANT	X	91	1015	Oran	d'	Oran	ANCIEN	Oran	Oran	Oran	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1031	1031	Sénégal	1	NEANT	Z	91	1000	Sénégal	du 	Sénégal	ANCIEN	Sénégal	Sénégal	Sénégal	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1034	1034	représentant les Français résidant à l'étranger	1	NEANT	Z	91	1051	Français à l'étranger	 	Français à l'étranger	ANCIEN	Français à l'étranger	représentant les Français résidant à l'étranger	représentant les Français résidant à l'étranger	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1050	1050	élu(e) par l'Assemblée Nationale	1	NEANT	Z	91	1055	Assemblée Nationale	\N	Assemblée Nationale	ANCIEN	Assemblée Nationale	élu(e) par l'Assemblée Nationale	élu(e) par l'Assemblée Nationale	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1001	1001	Gabon	1	NEANT	Z	91	1000	Gabon	du	Gabon	ANCIEN	Gabon	Gabon	Gabon	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1003	1003	Guinée	1	NEANT	Z	91	1000	Guinée	de la	Guinée	ANCIEN	Guinée	Guinée	Guinée	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1005	1005	Haute-Volta	1	NEANT	Z	91	1000	Haute-Volta	de la	Haute-Volta	ANCIEN	Haute-Volta	Haute-Volta	Haute-Volta	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1006	1006	Cameroun	1	NEANT	Z	91	1000	Cameroun	du	Cameroun	ANCIEN	Cameroun	Cameroun	Cameroun	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1007	1007	Soudan	1	NEANT	Z	91	1000	Soudan	du 	Soudan	ANCIEN	Soudan	Soudan	Soudan	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1008	1008	Ets Français de l'Inde	1	NEANT	Z	91	1000	Ets Français de l'Inde	des 	Ets Français de l'Inde	ANCIEN	Ets Français de l'Inde	Ets Français de l'Inde	Ets Français de l'Inde	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1009	1009	Madagascar	1	NEANT	Z	91	1000	Madagascar	de	Madagascar	ANCIEN	Madagascar	Madagascar	Madagascar	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1010	1010	Moyen-Congo	1	NEANT	Z	91	1000	Moyen-Congo	du	Moyen-Congo	ANCIEN	Moyen-Congo	Moyen-Congo	Moyen-Congo	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1013	1013	Côte d'Ivoire	1	NEANT	Z	91	1000	Côte d'Ivoire	de la	Côte d'Ivoire	ANCIEN	Côte d'Ivoire	Côte d'Ivoire	Côte d'Ivoire	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1014	1014	Oubangui-Chari	1	NEANT	Z	91	1000	Oubangui-Chari	d'	Oubangui-Chari	ANCIEN	Oubangui-Chari	Oubangui-Chari	Oubangui-Chari	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1015	1015	Niger	1	NEANT	Z	91	1000	Niger	du 	Niger	ANCIEN	Niger	Niger	Niger	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1016	1016	Dahomey	1	NEANT	Z	91	1000	Dahomey	du	Dahomey	ANCIEN	Dahomey	Dahomey	Dahomey	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1017	1017	Océanie	1	NEANT	Z	91	1000	Océanie	de l'	Océanie	ANCIEN	Océanie	Océanie	Océanie	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1019	1019	représentant les Français résidant au Maroc	1	NEANT	Z	91	1052	Maroc	 	Maroc	ANCIEN	Maroc	représentant les Français résidant au Maroc	représentant les Français résidant au Maroc	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1022	1022	représentant les Français résidant en Indochine	1	NEANT	Z	91	1053	Indochine	 	Indochine	ANCIEN	Indochine	représentant les Français résidant en Indochine	représentant les Français résidant en Indochine	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1023	1023	représentant les Français résidant en Tunisie	1	NEANT	Z	91	1054	Tunisie	 	Tunisie	ANCIEN	Tunisie	représentant les Français résidant en Tunisie	représentant les Français résidant en Tunisie	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1024	1024	Tchad	1	NEANT	Z	91	1000	Tchad	du 	Tchad	ANCIEN	Tchad	Tchad	Tchad	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1027	1027	Togo	1	NEANT	Z	91	1000	Togo	du 	Togo	ANCIEN	Togo	Togo	Togo	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1028	1028	Mauritanie	1	NEANT	Z	91	1000	Mauritanie	de la	Mauritanie	ANCIEN	Mauritanie	Mauritanie	Mauritanie	\N	\N	1946-12-08 00:00:00	1959-04-26 00:00:00	\N	\N	\N
1035	17	Charente-Inférieure	1	NEANT	Z	20	170	Charente -Inférieure	de la 	Charente -Inférieure	ANCIEN	Charente -Inférieure	Charente-Inférieure	Charente-Inférieure	\N	\N	1875-12-09 00:00:00	1945-12-31 00:00:00	\N	\N	\N
1037	1021	Algérie (Alger)	1	NEANT	Z	92	1000	Algérie(Alger)	d'	Algérie(Alger)	ANCIEN	Algérie (Alger)	Algérie (Alger)	Algérie (Alger)	\N	\N	1875-12-09 00:00:00	1945-12-31 00:00:00	\N	\N	\N
1038	1030	Algérie (Oran)	1	NEANT	Z	92	1000	Algérie(Oran)	d'	Algérie(Oran)	ANCIEN	Algérie (Oran)	Algérie (Oran)	Algérie (Oran)	\N	\N	1875-12-09 00:00:00	1945-12-31 00:00:00	\N	\N	\N
1039	1033	Algérie (Constantine)	1	NEANT	Z	92	1000	Algérie(Constantine)	d'	Algérie(Constantine)	ANCIEN	Algérie (Constantine)	Algérie (Constantine)	Algérie (Constantine)	\N	\N	1875-12-09 00:00:00	1945-12-31 00:00:00	\N	\N	\N
9998	9998	inamovible	1	NEANT	Z	92	9998	inamovibles	\N	inamovibles	ANCIEN	inamovibles	inamovible	inamovible	\N	\N	1875-12-09 00:00:00	1945-12-31 00:00:00	\N	\N	\N
30	03	Allier	2	SM	A	30	30	Allier	de l'	Allier	ACTIF	Allier	Allier	Allier	2	\N	1959-04-28 00:00:00	\N	http://www.cg03.fr/	\N	\N
490	49	Maine-et-Loire	4	RP	B	18	490	Maine-et-Loire	de 	Maine-et-Loire	ACTIF	Maine-et-Loire	Maine-et-Loire	Maine-et-Loire	1	\N	1959-04-28 00:00:00	\N	http://www.cg49.fr/	\N	2017-09-08 23:17:19
540	54	Meurthe-et-Moselle	4	RP	B	27	540	Meurthe-et-Moselle	de la 	Meurthe-et-Moselle	ACTIF	Meurthe-et-Moselle	Meurthe-et-Moselle	Meurthe-et-Moselle	1	\N	1959-04-28 00:00:00	\N	http://www.cg54.fr/	\N	\N
550	55	Meuse	2	SM	B	27	550	Meuse	de la 	Meuse	ACTIF	Meuse	Meuse	Meuse	1	\N	1959-04-28 00:00:00	\N	http://www.cg55.fr/	\N	\N
590	59	Nord	11	RP	B	26	590	Nord	du 	Nord	ACTIF	Nord	Nord	Nord	1	\N	1959-04-28 00:00:00	\N	http://www.cg59.fr/	\N	\N
600	60	Oise	4	RP	B	26	600	Oise	de l'	Oise	ACTIF	Oise	Oise	Oise	1	\N	1959-04-28 00:00:00	\N	http://www.cg60.fr/	\N	2017-09-08 23:17:19
615	75	Paris	12	RP	C	10	615	Paris	de 	Paris	ACTIF	Paris	Paris	Paris	1	\N	1968-01-01 00:00:00	\N	\N	\N	\N
670	67	Bas-Rhin	5	RP	C	27	670	Bas-Rhin	du 	Rhin Bas	ACTIF	Bas-Rhin	Bas-Rhin	Bas-Rhin	2	\N	1959-04-28 00:00:00	\N	http://www.cg67.fr/	\N	\N
680	68	Haut-Rhin	4	RP	C	27	680	Haut-Rhin	du 	Rhin Haut	ACTIF	Haut-Rhin	Haut-Rhin	Haut-Rhin	2	\N	1959-04-28 00:00:00	\N	http://www.cg68.fr/	\N	\N
700	70	Haute-Saône	2	SM	C	24	700	Haute-Saône	de la 	Saône Haute	ACTIF	Haute-Saône	Haute-Saône	Haute-Saône	2	\N	1959-04-28 00:00:00	\N	http://www.cg70.fr/	\N	\N
775	93	Seine-Saint-Denis	6	RP	C	10	930	Seine-Saint-Denis	de la 	Seine-Saint-Denis	ACTIF	Seine-Saint-Denis	Seine-Saint-Denis	Seine-Saint-Denis	1	\N	1968-01-01 00:00:00	\N	http://www.cg93.fr/	\N	\N
810	81	Tarn	2	SM	C	29	810	Tarn	du 	Tarn	ACTIF	Tarn	Tarn	Tarn	2	\N	1959-04-28 00:00:00	\N	http://www.cg81.fr/	\N	\N
828	95	Val-d'Oise	5	RP	C	10	950	Val-d'Oise	du 	Val-d'Oise	ACTIF	Val-d'Oise	Val-d'Oise	Val-d'Oise	1	\N	1968-01-01 00:00:00	\N	http://www.cg95.fr/	\N	\N
830	83	Var	4	RP	C	21	830	Var	du 	Var	ACTIF	Var	Var	Var	2	\N	1959-04-28 00:00:00	\N	http://www.cg83.fr/	\N	\N
840	84	Vaucluse	3	RP	C	21	840	Vaucluse	du 	Vaucluse	ACTIF	Vaucluse	Vaucluse	Vaucluse	2	\N	1959-04-28 00:00:00	\N	http://www.vaucluse.fr/	\N	2024-04-09 18:43:17
850	85	Vendée	3	RP	C	18	850	Vendée	de la 	Vendée	ACTIF	Vendée	Vendée	Vendée	2	\N	1959-04-28 00:00:00	\N	http://www.cg85.fr/	\N	\N
880	88	Vosges	2	SM	C	27	880	Vosges	des 	Vosges	ACTIF	Vosges	Vosges	Vosges	2	\N	1959-04-28 00:00:00	\N	http://www.cg88.fr/	\N	\N
895	78	Yvelines	6	RP	C	10	895	Yvelines	des 	Yvelines	ACTIF	Yvelines	Yvelines	Yvelines	1	\N	1968-01-01 00:00:00	\N	http://www.yvelines.fr	\N	\N
971	971	Guadeloupe	3	RP	C	50	971	Guadeloupe	de la 	Guadeloupe	ACTIF	Guadeloupe	Guadeloupe	Guadeloupe	1	\N	1959-04-28 00:00:00	\N	http://www.cg971.fr	\N	\N
972	972	Martinique	2	SM	C	52	973	Martinique	de la 	Martinique	ACTIF	Martinique	Martinique	Martinique	1	\N	1959-04-28 00:00:00	\N	http://www.cg972.fr/	\N	\N
982	988	Nouvelle-Calédonie	2	SM	B	60	990	Nouvelle-Calédonie	de la 	Nouvelle-Calédonie	ACTIF	Nouvelle-Calédonie	Nouvelle-Calédonie	Nouvelle-Calédonie	1	\N	1959-04-28 00:00:00	\N	\N	\N	\N
984	986	Iles Wallis et Futuna	1	SM	A	62	982	Iles Wallis et Futuna	des 	Wallis et Futuna	ACTIF	Iles Wallis et Futuna	Iles Wallis et Futuna	Iles Wallis et Futuna	2	\N	1959-04-28 00:00:00	\N	\N	\N	\N
990	976	Mayotte	2	SM	C	70	976	Mayotte	de 	Mayotte	ACTIF	Mayotte	Mayotte	Mayotte	1	\N	1959-04-28 00:00:00	\N	\N	\N	\N
500	50	Manche	3	RP	B	25	500	Manche	de la 	Manche	ACTIF	Manche	Manche	Manche	1	\N	1959-04-28 00:00:00	\N	\N	\N	\N
570	57	Moselle	5	RP	B	27	570	Moselle	de la 	Moselle	ACTIF	Moselle	Moselle	Moselle	1	\N	1959-04-28 00:00:00	\N	http://www.cg57.fr/	\N	\N
730	73	Savoie	2	SM	C	30	730	Savoie	de la 	Savoie	ACTIF	Savoie	Savoie	Savoie	2	\N	1959-04-28 00:00:00	\N	http://www.cg73.fr/	\N	2017-09-11 15:34:40
1021	1021	Alger	\N	NEANT	X	40	1000	Alger	d'	Alger	ANCIEN	Alger	Alger	Alger	\N	\N	1959-04-28 00:00:00	1962-07-03 00:00:00	\N	\N	\N
1040	1040	Tizi-Ouzou	\N	NEANT	X	40	1005	Tizi-Ouzou	de 	Tizi-Ouzou	ANCIEN	Tizi-Ouzou	Tizi-Ouzou	Tizi-Ouzou	\N	\N	1959-04-28 00:00:00	1962-07-03 00:00:00	\N	\N	\N
1041	1041	Saoura	\N	NEANT	X	40	1040	Saoura	de 	Saoura	ANCIEN	Saoura	Saoura	Saoura	\N	\N	1959-04-28 00:00:00	1962-07-03 00:00:00	\N	\N	\N
1042	1042	Bône	\N	NEANT	X	40	1035	Bône	de 	Bône	ANCIEN	Bône	Bône	Bône	\N	\N	1959-04-28 00:00:00	1962-07-03 00:00:00	\N	\N	\N
1043	1043	Orléansville-Médéa	\N	NEANT	X	40	1010	Orléansville-Médéa	de 	Orléansville-Médéa	ANCIEN	Orléansville-Médéa	Orléansville-Médéa	Orléansville-Médéa	\N	\N	1959-04-28 00:00:00	1962-07-03 00:00:00	\N	\N	\N
1044	1044	Mostaganem-Tiaret	\N	NEANT	X	40	1020	Mostaganem-Tiaret	de 	Mostaganem-Tiaret	ANCIEN	Mostaganem-Tiaret	Mostaganem-Tiaret	Mostaganem-Tiaret	\N	\N	1959-04-28 00:00:00	1962-07-03 00:00:00	\N	\N	\N
1045	1045	Setif-Batna	\N	NEANT	X	40	1030	Setif-Batna	de 	Setif-Batna	ANCIEN	Setif-Batna	Setif-Batna	Setif-Batna	\N	\N	1959-04-28 00:00:00	1962-07-03 00:00:00	\N	\N	\N
1025	976	Comores	\N	NEANT	X	63	995	Comores	des	Comores	ANCIEN	Comores	Comores	Comores	\N	\N	1959-04-28 00:00:00	1975-07-06 00:00:00	\N	\N	\N
1012	1012	Côte française des Somalis	\N	NEANT	X	72	996	Côte française des Somalis	de la 	Côte française des Somalis	ANCIEN	Somalis	Côte française des Somalis av. mars 1967	Côte française des Somalis devenue Territoire des Afar et des Issas le 19 mars 1967	\N	\N	1959-04-28 00:00:00	1967-03-19 00:00:00	\N	\N	\N
1030	1030	Oran-Tlemcen	\N	NEANT	X	40	1015	Oran-Tlemcen	d'	Oran-Tlemcen	ANCIEN	Oran-Tlemcen	Oran-Tlemcen	Oran-Tlemcen	\N	\N	1959-04-28 00:00:00	1962-07-03 00:00:00	\N	\N	\N
1033	1033	Constantine	\N	NEANT	X	40	1025	Constantine	de 	Constantine	ANCIEN	Constantine	Constantine	Constantine	\N	\N	1959-04-28 00:00:00	1962-07-03 00:00:00	\N	\N	\N
1046	1046	Oasis	\N	NEANT	X	40	1045	Oasis	d'	Oasis	ANCIEN	Oasis	Oasis	Oasis	\N	\N	1959-04-28 00:00:00	1962-07-03 00:00:00	\N	\N	\N
380	38	Isère	5	RP	B	30	380	Isère	de l'	Isère	ACTIF	Isère	Isère	Isère	1	\N	1959-04-28 00:00:00	\N	http://www.cg38.fr/	\N	\N
510	51	Marne	3	RP	B	27	510	Marne	de la 	Marne	ACTIF	Marne	Marne	Marne	1	\N	1959-04-28 00:00:00	\N	\N	\N	\N
10	01	Ain	3	RP	A	30	10	Ain	de l'	Ain	ACTIF	Ain	Ain	Ain	2	\N	1959-04-28 00:00:00	\N	http://www.cg01.fr/	\N	\N
470	47	Lot-et-Garonne	2	SM	B	28	470	Lot-et-Garonne	de 	Lot-et-Garonne	ACTIF	Lot-et-Garonne	Lot-et-Garonne	Lot-et-Garonne	1	\N	1959-04-28 00:00:00	\N	http://www.lot-et-garonne.fr	\N	\N
40	04	Alpes de Haute-Provence	1	SM	A	21	40	Alpes de Haute-Provence	des 	Alpes de Haute-Provence	ACTIF	Alpes Haute-Provence	Alpes de Haute-Provence	Alpes de Haute-Provence	2	\N	1969-04-13 00:00:00	\N	http://www.cg04.fr/	\N	\N
130	13	Bouches-du-Rhône	8	RP	A	21	130	Bouches-du-Rhône	des 	Bouches-du-Rhône	ACTIF	Bouches-du-Rhône	Bouches-du-Rhône	Bouches-du-Rhône	2	\N	1959-04-28 00:00:00	\N	http://www.cg13.fr/	\N	\N
170	17	Charente-Maritime	3	RP	A	28	170	Charente-Maritime	de la 	Charente-Maritime	ACTIF	Charente-Maritime	Charente-Maritime	Charente-Maritime	2	\N	1959-04-28 00:00:00	\N	\N	\N	\N
280	28	Eure-et-Loir	3	RP	A	23	280	Eure-et-Loir	d'	Eure-et-Loir	ACTIF	Eure-et-Loir	Eure-et-Loir	Eure-et-Loir	2	\N	1959-04-28 00:00:00	\N	http://www.cg28.fr/	\N	\N
440	44	Loire-Atlantique	5	RP	B	18	440	Loire-Atlantique	de la 	Loire-Atlantique	ACTIF	Loire-Atlantique	Loire-Atlantique	Loire-Atlantique	1	\N	1957-03-09 00:00:00	\N	http://www.cg44.fr/	\N	\N
520	52	Haute-Marne	2	SM	B	27	520	Haute-Marne	de la 	Marne Haute	ACTIF	Haute-Marne	Haute-Marne	Haute-Marne	1	\N	1959-04-28 00:00:00	\N	http://www.haute-marne.org/	\N	\N
1055	1055	Français établis hors de France	\N	NEANT	X	90	999	Français établis hors de France	représentant les 	Français établis hors de France	ANCIEN	Français établis hors de France	Français établis hors de France	Français établis hors de France	\N	\N	\N	1962-07-03 00:00:00	\N	2015-02-10 11:15:17	\N
1056	1056	Alger, des Oasis et de la Saoura	\N	NEANT	X	90	999	Alger, des Oasis et de la Saoura	d' 	Alger, des Oasis et de la Saoura	ANCIEN	Alger, des Oasis et de la Saoura	Alger, des Oasis et de la Saoura	Alger, des Oasis et de la Saoura	\N	\N	\N	1962-07-03 00:00:00	\N	2015-02-10 11:15:17	\N
535	535	Meurthe	\N	NEANT	X	13	535	Meurthe	de la 	Meurthe	ANCIEN	Meurthe	Meurthe	Meurthe	\N	\N	1790-01-27 00:00:00	1871-05-18 00:00:00	\N	2014-02-26 11:21:02	\N
9900	99	Étranger	\N	NEANT	X	ETRG	999	Étranger	de l' 	Étranger	ANCIEN	Étranger	Étranger	Étranger	\N	\N	1950-01-01 00:00:00	2014-01-01 00:00:00	\N	2014-02-26 11:21:19	\N
\.

COPY elusen (eluid, dptnum, eludatdeb, eludatelu, eludatfin, etadebmancod, etafinmancod, temvalcod, evelic, evelib, evelil, eluanndeb, eluannfin, typmancod, senmat, eludatcum, turelucod, syscredat, sysmajdat) FROM stdin;
398	265	1986-10-02 00:00:00	1986-09-28 00:00:00	1995-10-01 00:00:00	ELECTION	FINMAN	ANCIEN	\N	\N	\N	\N	\N	SENAT	86039K	\N	RP	\N	\N
399	265	1995-10-02 00:00:00	1995-09-24 00:00:00	2000-04-27 00:00:00	REN1	CESMEMGVT	ANCIEN	\N	\N	\N	\N	\N	SENAT	86039K	2000-03-27 00:00:00	RP	\N	2016-12-14 15:24:14
335	895	1986-10-02 00:00:00	1986-09-28 00:00:00	1995-10-01 00:00:00	ELECTION	FINMAN	ANCIEN	\N	\N	\N	\N	\N	SENAT	86034E	\N	RP	\N	\N
336	895	1995-10-02 00:00:00	1995-09-24 00:00:00	2004-04-30 00:00:00	REN1	CESMEMGVT	ANCIEN	\N	\N	\N	\N	\N	SENAT	86034E	2004-03-31 00:00:00	RP	\N	\N
51272	1053	2017-10-02 00:00:00	2017-09-24 00:00:00	2023-10-01 00:00:00	REN	FINMAN	ANCIEN	\N	Nouveau	\N	\N	2023	\N	11027H	\N	RP	2017-09-24 00:00:00	2017-09-24 00:00:00
51230	895	2017-10-02 00:00:00	2017-09-24 00:00:00	2023-10-01 00:00:00	REN3	FINMAN	ANCIEN	\N	Nouveau	\N	\N	2023	\N	86034E	\N	RP	2017-09-24 00:00:00	2017-09-24 00:00:00
10907	265	2004-10-01 00:00:00	2004-09-26 00:00:00	2010-01-07 00:00:00	ELECTION	CESDEPUTEEUR	ANCIEN	\N	\N	Elu député européen	\N	2010	SENAT	86039K	\N	RP	\N	\N
10759	850	2004-10-01 00:00:00	2004-09-26 00:00:00	2014-09-30 00:00:00	ELECTION	FINMAN	ANCIEN	\N	\N	\N	\N	\N	SENAT	04033B	\N	NR	\N	2014-09-28 16:40:50
12676	1053	2011-10-01 00:00:00	2011-09-25 00:00:00	2012-07-21 00:00:00	ELECTION	CESMEMGVT	ANCIEN	\N	\N	\N	\N	\N	SENAT	11027H	\N	RP	\N	\N
12729	895	2011-10-01 00:00:00	2011-09-25 00:00:00	2017-10-01 00:00:00	REN2	FINMAN	ANCIEN	\N	\N	\N	\N	\N	SENAT	86034E	\N	RP	\N	2017-09-24 18:17:56
11286	895	2007-10-01 00:00:00	\N	2011-09-30 00:00:00	REMPLACE	FINMAN	ANCIEN	\N	\N	En remplacement de Mme Adeline Gousseau, démissionnaire	\N	\N	SENAT	86034E	\N	RP	\N	\N
14085	850	2014-10-01 00:00:00	2014-09-28 00:00:00	2020-09-30 00:00:00	REN	FINMAN	ANCIEN	\N	Nouveau	\N	\N	\N	SENAT	04033B	\N	RP	2014-09-28 16:40:49	\N
13763	1053	2014-05-03 00:00:00	\N	2017-10-01 00:00:00	REPRISE	FINMAN	ANCIEN	\N	Retour de Gouvernement	\N	\N	\N	SENAT	11027H	\N	NR	2014-05-05 10:32:04	2017-09-24 18:59:59
51908	850	2020-10-01 00:00:00	2020-09-27 00:00:00	2024-10-21 00:00:00	REN2	FINMEMGVT	ANCIEN	\N	Nouveau	\N	\N	2024	\N	04033B	\N	RP	\N	\N
53225	1053	2023-10-02 00:00:00	2023-09-24 00:00:00	\N	REN2	ACTIF	ACTIF	\N	\N	\N	\N	\N	SENAT	11027H	\N	NR	\N	\N
53323	895	2023-10-02 00:00:00	2023-09-24 00:00:00	\N	REN4	ACTIF	ACTIF	\N	\N	\N	\N	\N	SENAT	86034E	\N	NR	\N	\N
54842	850	2025-11-13 00:00:00	2025-11-13 00:00:00	2026-09-30 00:00:00	REPRISE	FINMAN	ANCIEN	\N	\N	\N	\N	\N	\N	04033B	\N	NR	2025-11-12 15:21:55	2026-09-27 19:26:47
55046	850	2026-10-01 00:00:00	2026-09-27 00:00:00	\N	REN1	ACTIF	ACTIF	\N	\N	\N	\N	\N	SENAT	04033B	\N	NR	2026-09-27 19:26:47	2026-09-27 19:26:47
\.

COPY etadebman (etadebmancod, etadebmanlic, etadebmanlib, etadebmannumtri, etadebmanlil, etadebmanlicfem, etadebmanlibfem, etadebmanlilfem, etadebmanlicplu, etadebmanlibplu, etadebmanlilplu, syscredat, sysmajdat) FROM stdin;
ELECTION	Election	Nouveau	1	Election	Election	Nouvelle	Election	Elections	Nouveaux	Elections	\N	\N
REELECTION	Réélection	Réélu	2	Réélu	Réélection	Réélue	Réélue	Réélection	Réélus	Réélus	\N	\N
REMPLACE	Remplace	Remplace	3	Remplace	Remplace	Remplace	Remplace	Remplace	Remplace	Remplacent	\N	\N
REN	Renouvellement	Réélu	4	Réélu	Renouvellement	Réélue	Réélue	Renouvellement	Réélus	Réélus	\N	\N
REN1	Renouvellement 1	Réélu	5	Réélu	Renouvellement 1	Réélue	Réélue	Renouvellement 1	Réélus	Réélus	\N	\N
REN2	Renouvellement 2	Réélu	6	Réélu	Renouvellement 2	Réélue	Réélue	Renouvellement 2	Réélus	Réélus	\N	\N
REN3	Renouvellement 3	Réélu	7	Réélu	Renouvellement 3	Réélue	Réélue	Renouvellement 3	Réélus	Réélus	\N	\N
REN4	Renouvellement 4	Réélu	8	Réélu	Renouvellement 4	Réélue	Réélue	Renouvellement 4	Réélus	Réélus	\N	\N
REN5	Renouvellement 5	Réélu	9	Réélu	Renouvellement 5	Réélue	Réélue	Renouvellement 5	Réélus	Réélus	\N	\N
REN6	Renouvellement 6	Réélu	10	Réélu	Renouvellement 6	Réélue	Réélue	Renouvellement 6	Réélus	Réélus	\N	\N
REN7	Renouvellement 7	Réélu	11	Réélu	Renouvellement 7	Réélue	Réélue	Renouvellement 7	Réélus	Réélus	\N	\N
REPRISE	Reprise suite à fin fon. membre Gvt	Reprise de l'exercice du mandat de sénateur suite à la cessation de fonction de membre du Gouvernement	12	Reprise de l'exercice du mandat de sénateur suite à la cessation de fonction de membre du Gouvernement	Reprise de l'exercice du mandat de sénateur suite à la cessation de fonction de membre du Gouvernement	Reprise de l'exercice du mandat de sénateur suite à la cessation de fonction de membre du Gouvernement	Reprise de l'exercice du mandat de sénateur suite à la cessation de fonction de membre du Gouvernement	Reprise de l'exercice du mandat de sénateur suite à la cessa	Reprise de l'exercice du mandat de sénateur suite à la cessation de fonction de membre du Gouvernement	Reprise de l'exercice du mandat de sénateur suite à la cessation de fonction de membre du Gouvernement	\N	\N
\.

COPY etafinman (etafinmancod, etafinmanlic, etafinman, etafinmannumtri, etafinmanlil, etafinmanlicfem, etafinmanlibfem, etafinmanlilfem, etafinmanlicplu, etafinmanlibplu, etafinmanlilplu, syscredat, sysmajdat) FROM stdin;
CESMEMGVT	Membre Gouvernement	Devenu membre du Gouvernement	8	Devenu membre du Gouvernement	Membre Gouvernement	Devenue membre du Gouvernement	Devenue membre du Gouvernement	Membres Gouvernement	Devenus membres du Gouvernement	Devenus membres du Gouvernement	\N	\N
CESDEPUTE	Élu député	Élu député	9	Élu député	Élue députée	Élue députée	Élue députée	Élus députés	Élus députés	Élu députés	\N	\N
CESMEMCC	Nommé membre CC	Nommé membre du Conseil Constitutionnel	11	Nommé membre du Conseil Constitutionnel	Nommée membre CC	Nommée membre du Conseil Constitutionnel	Nommée membre du Conseil Constitutionnel	Nommés membres CC	Nommés membres du Conseil Constitutionnel	Nommés membres du Conseil Constitutionnel	\N	\N
DEMPREMIN	Démission (Premier ministre)	Démissionnaire (devenu Premier ministre)	13	Démissionnaire (devenu Premier ministre)	Démission (Premier ministre)	Démissionnaire (devenue Premier ministre)	Démissionnaire (devenue Premier ministre)	Démissions (Premiers ministres)	Démissionnaires (devenus Premiers ministres)	Devenus Premiers ministres (Démissionnaires)	\N	\N
ACTIF	En Cours	En Cours	0	En Cours	En Cours	En Cours	En Cours	En Cours	En Cours	En Cours	\N	\N
ANNCC	Annulé par CC	Annulé par le Conseil Constitutionnel	18	Élection annulée par le Conseil Constitutionnel	Annulé par CC	Annulé par le Conseil Constitutionnel	Élection annulée par le Conseil Constitutionnel	Annulés par CC	Annulés par le Conseil Constitutionnel	Élections annulées par le Conseil Constitutionnel	\N	\N
DECCC	Dech. par CC	Déchéance par le Conseil Constitutionnel	19	Déchéance constatée par le Conseil Constitutionnel	Dech. par CC	Déchéance par le Conseil Constitutionnel	Déchéance constatée par le Conseil Constitutionnel	Dech. par CC	Déchéances par le Conseil Constitutionnel	Déchéances constatée par le Conseil Constitutionnel	\N	\N
DECEDE	Décédé	Décédé	2	Décédé	Décédée	Décédée	Décédée	Décédés	Décédés	Décédés	\N	\N
DEM	Démissionnaire	Démissionnaire	12	Démissionnaire	Démissionnaire	Démissionnaire	Démissionnaire	Démissionnaires	Démissionnaires	Démissionnaires	\N	\N
DEMMEMGVT	Démission (Membre Gouvt)	Démissionnaire (devenu membre du Gouvernement)	14	Démissionnaire (devenu membre du Gouvernement)	Démission (Membre Gouvt)	Démissionnaire (devenue membre du Gouvernement)	Démissionnaire (devenue membre du Gouvernement)	Démissions (Membres Gouvt)	Démissionnaires (devenus membres du Gouvernement)	Devenus membres du Gouvernement	\N	\N
FINMAN	Fin de mandat	Fin de mandat	3	Fin de mandat	Fin de mandat	Fin de mandat	Fin de mandat	Fins de mandat	Fins de mandat	Fins de mandat	\N	\N
NONREELU	Non réélu	Non réélu	5	Non réélu	Non réélue	Non réélue	Non réélue	Non réélus	Non réélus	Non réélus	\N	\N
NONREP	Ne se représente pas	Ne se représente pas	4	Ne se représente pas	Ne se représente pas	Ne se représente pas	Ne se représente pas	Ne se représentent pas	Ne se représentent pas	Ne se représentent pas	\N	\N
DEMDEPUTE	Démission (Député)	Démissionnaire (élu député)	15	Démissionnaire (élu député)	Démission (Députée)	Démissionnaire (élue député)	Démissionnaire (élue députée)	Démissions (Députés)	Démissionnaires (élus députés)	Élus députés	\N	\N
CESMANORD	Cessation de mandat (1962)	Cessation de mandat (Ordonnance de 1962)	21	Cessation de mandat (en application de l'ordonnance n°62-737 du 03-07-1962 consécutive à l'indépendance de l'Algérie)	Cessation de mandat (1962)	Cessation de mandat (Ordonnance du 03-07-1962)	Cessation de mandat (en application de l'ordonnance n°62-737 du 03-07-1962 consécutive à l'indépendance de l'Algérie)	Cessations de mandat (1962)	Cessations de mandat (Ordonnance du 03-07-1962)	Cessations de mandat (en application de l'ordonnance n°62-737 du 03-07-1962 consécutive à l'indépendance de l'Algérie)	\N	\N
DEMMEMCC	Démission (Membre CC)	Démissionnaire (nommé membre du Conseil Constitutionnel)	17	Démissionnaire (nommé membre du Conseil Constitutionnel)	Démission (Membre CC)	Démissionnaire (nommée membre du Conseil Constitutionnel)	Nommée membre du Conseil Constitutionnel	Démissions (Membres CC)	Démissionnaires (nommés membres du Conseil Constitutionnel)	Nommés membres du Conseil Constitutionnel	\N	\N
CESDEPUTEEUR	Élu député européen	Élu député européen	10	Élu député européen	Élue députée européenne	Élue députée européenne	Élue députée européenne	Élus députés européens	Élus députés européens	Élus députés européens	\N	\N
DEMDEPUTEEUR	Démission (Député européen)	Démissionnaire (élu député européen)	16	Démissionnaire (élu député européen)	Démission (élue députée européenne)	Démissionnaire (élue députée européenne)	Démissionnaire (élue députée européenne)	Démission (élus députés européens)	Démissionnaires (élus députés européens)	Démissionnaires (élus députés européens)	\N	\N
CESPREMIN	Premier ministre	Devenu Premier ministre	7	Devenu Premier ministre	Premier ministre	Devenue Premier ministre	Devenue Premier ministre	Premiers ministres	Devenus Premiers ministres	Devenus Premiers ministres	\N	\N
REPEXE	Reprise mandat d'ancien membre du Gvt	Reprise de l'exercice du mandat d'un ancien membre du Gouvernement	22	Reprise de l'exercice du mandat d'un ancien membre du Gouvernement	Reprise de l'exercice du mandat d'un ancien membre du Gouver	Reprise de l'exercice du mandat d'un ancien membre du Gouvernement	Reprise de l'exercice du mandat d'un ancien membre du Gouvernement	Reprise de l'exercice du mandat d'un ancien membre du Gouver	Reprise de l'exercice du mandat d'un ancien membre du Gouvernement	Reprise de l'exercice du mandat d'un ancien membre du Gouvernement	\N	\N
CESMAN	Cessation de mandat	Cessation de mandat	23	Cessation de mandat	Cessation de mandat	Cessation de mandat	Cessation de mandat	Cessation de mandat	Cessation de mandat	Cessation de mandat	\N	\N
SEREP	En cours, se représente	En cours, se représente	2	En cours, se représente	En cours, se représente	En cours, se représente	En cours, se représente	En cours, se représente	En cours, se représente	En cours, se représente	\N	\N
DEMCC	Démissionné d'office par le Conseil constitutionnel	Déclaré démissionnaire d'office de son mandat de sénateur par le Conseil constitutionnel	24	Déclaré démissionnaire d'office de son mandat de sénateur par le Conseil constitutionnel	Démissionnée d'office par le Conseil constitutionnel	Déclarée démissionnaire d'office de son mandat de sénateur par le Conseil constitutionnel	Déclarée démissionnaire d'office de son mandat de sénateur par le Conseil constitutionnel	Démissionnés d'office par le Conseil constitutionnel	Déclarés démissionnaires d'office de leurs mandats de sénateur par le Conseil constitutionnel	Déclarés démissionnaires d'office de leurs mandats de sénateur par le Conseil constitutionnel	\N	\N
FININCOMPAT	De droit (incompatibilité mandats locaux)	De droit (incompatibilité mandats locaux)	26	De droit (incompatibilité mandats locaux)	De droit (incompatibilité mandats locaux)	De droit (incompatibilité mandats locaux)	De droit (incompatibilité mandats locaux)	De droit (incompatibilité mandats locaux)	De droit (incompatibilité mandats locaux)	De droit (incompatibilité mandats locaux)	\N	\N
FINMEMGVT	De droit (membre du Gouvernement)	Membre du Gouvernement	27	Membre du Gouvernement	Membre du Gouvernement	Membre du Gouvernement	Membre du Gouvernement	Membres du Gouvernement	Membres du Gouvernement	Membres du Gouvernement	\N	\N
\.

COPY foncom (foncomcod, foncomlib, foncomlic, foncomnumtri, foncomlil, foncomlicfem, foncomlibfem, foncomlilfem, foncomlicplu, foncomlibplu, foncomlilplu, foncomlicfemplu, foncomlibfemplu, foncomlilfemplu, syscredat, sysmajdat) FROM stdin;
MEMBRECOM	 	Membre	9	 	Membre	 	 	Membres	 	 	Membres	Membres	Membres	\N	\N
PDTCOM	Président	Président	1	Président	Présidente	Présidente	Présidente	Présidents	Présidents	Présidents	Présidentes	Présidentes	Présidentes	\N	\N
RAPGENCOM	Rapporteur général	Rapporteur général	2	Rapporteur général	Rapporteure générale	Rapporteure générale	Rapporteure générale	Rapporteurs généraux	Rapporteurs généraux	Rapporteurs généraux	Rapporteures générales	Rapporteures générales	Rapporteures générales	\N	\N
SECRETCOM	Secrétaire	Secrétaire	5	Secrétaire	Secrétaire	Secrétaire	Secrétaire	Secrétaires	Secrétaires	Secrétaires	Secrétaires	Secrétaires	Secrétaires	\N	\N
VICPDTCOM	Vice-Président	Vice-Président	4	Vice-Président	Vice-Présidente	Vice-Présidente	Vice-Présidente	Vice-Présidents	Vice-Présidents	Vice-Présidents	Vice-Présidentes	Vice-Présidentes	Vice-Présidentes	\N	\N
RAPCOM	Rapporteur	Rapporteur	7	Rapporteur	Rapporteure	Rapporteure	Rapporteur	Rapporteurs	Rapporteurs	Rapporteurs	Rapporteures	Rapporteures	Rapporteures	\N	\N
RAPADJCOM	Rapporteur adjoint	Rapporteur adjoint	8	Rapporteur adjoint	Rapporteure adjointe	Rapporteure adjointe	Rapporteur adjoint	Rapporteurs adjoints	Rapporteurs adjoints	Rapporteurs adjoints	Rapporteures adjointes	Rapporteures adjointes	Rapporteures adjointes	\N	\N
VICPDTHONCOM	Vice-Président d'honneur	Vice-Président d'honneur	10	Vice-Président d'honneur	Vice-Présidente d'honneur	Vice-Présidente d'honneur	Vice-Présidente d'honneur	Vice-Présidents d'honneur	Vice-Présidents d'honneur	Vice-Présidents d'honneur	Vice-Présidentes d'honneur	Vice-Présidentes d'honneur	Vice-Présidentes d'honneur	\N	\N
VICPDTPRECOM	Premier Vice-Président	Premier Vice-Président	3	Premier Vice-Président	Première Vice-Présidente	Première Vice-Présidente	Première Vice-Présidente	Premiers Vice-Présidents	Premiers Vice-Présidents	Premiers Vice-Présidents	Premières Vice-Présidentes	Premières Vice-Présidentes	Premières Vice-Présidentes	\N	\N
PDTRAPCOM	Président et rapporteur	Président et rapporteur	1	Président et rapporteur	Présidente et rapporteure	Présidente et rapporteure	Présidente et rapporteure	Président et rapporteur	Président et rapporteur	Président et rapporteur	Présidentes et rapporteures	Présidentes et rapporteures	Présidentes et rapporteures	\N	\N
VICPDTRAPCOM	Vice-Président et rapporteur	Vice-Président et rapporteur	4	Vice-Président et rapporteur	Vice-Président et rapporteur	Vice-Présidente et rapporteure	Vice-Présidente et rapporteure	Vice-Président et rapporteur	Vice-Président et rapporteur	Vice-Président et rapporteur	Vice-Présidentes et rapporteures	Vice-Présidentes et rapporteures	Vice-Présidentes et rapporteures	\N	\N
SECRETRAPCOM	Secrétaire Rapporteur	Secrétaire Rapporteur	6	Secrétaire Rapporteur	Secrétaire rapporteure	Secrétaire rapporteure	Secrétaire rapporteur	Secrétaires rapporteur	Secrétaires Rapporteur	Secrétaires Rapporteur	Secrétaires rapporteures	Secrétaires rapporteures	Secrétaires rapporteures	\N	\N
\.

COPY fongrppol (fongrppolcod, fongrppollib, fongrppollic, fongrppolnumtri, fongrppollil, fongrppollibfem, fongrppollicfem, fongrppollilfem, fongrppollibplu, fongrppollicplu, fongrppollilplu, syscredat, sysmajdat, fongrppollicfemplu, fongrppollibfemplu, fongrppollilfemplu) FROM stdin;
DELPOL	Délégué	Délégué	5	Délégué	Déléguée	Déléguée	Déléguée	Délégués	Délégués	Délégués	\N	\N	Déléguées	Déléguées	Déléguées
MEMBREPOL	                                           	Membre	6	                                           	                                           	Membre	                                           	                                           	Membres	                                           	\N	\N	Membres	                                           s	                                           s
PDTPOL	Président	Président	1	Président	Présidente	Présidente	Présidente	Présidents	Présidents	Présidents	\N	\N	Présidentes	Présidentes	Présidentes
PDTDELPOL	Président délégué	Président délégué	2	Président délégué	Présidente déléguée	Présidente déléguée	Présidente déléguée	Présidents délégués	Présidents délégués	Présidents délégués	\N	\N	Présidentes déléguées	Présidentes déléguées	Présidentes déléguées
VICPDTPOL	Vice-Président	Vice-Président	3	Vice-Président	Vice-Présidente	Vice-Présidente	Vice-Présidente	Vice-Présidents	Vice-Présidents	Vice-Présidents	\N	\N	Vice-Présidentes	Vice-Présidentes	Vice-Présidentes
VICPDTDELPOL	Vice-Président délégué	Vice-Président délégué	4	Vice-Président délégué	Vice-Présidente déléguée	Vice-Présidente déléguée	Vice-Présidente déléguée	Vice-Présidents délégués	Vice-Présidents délégués	Vice-Présidents délégués	\N	\N	Vice-Présidentes déléguées	Vice-Présidentes déléguées	Vice-Présidentes déléguées
\.

COPY fonmemcom (fonmemcomid, foncomcod, fonmemcomdatdeb, fonmemcomdatfin, fonmemcomrngprt, temvalcod, evelic, evelib, evelil, eveobs, memcomid, syscredat, sysmajdat) FROM stdin;
289	MEMBRECOM	1997-01-30 00:00:00	2001-10-03 00:00:00	\N	ANCIEN	\N	\N	\N	\N	289	\N	\N
67	SECRETCOM	1995-10-05 00:00:00	1998-10-06 00:00:00	4	ANCIEN	\N	\N	\N	\N	67	\N	\N
1391	MEMBRECOM	2003-02-12 00:00:00	2003-07-21 00:00:00	\N	ANCIEN	\N	\N	\N	\N	977	\N	\N
2365	PDTCOM	2003-05-15 00:00:00	2004-04-30 00:00:00	\N	ANCIEN	\N	\N	\N	\N	1805	\N	\N
489	MEMBRECOM	1989-10-04 00:00:00	1995-10-05 00:00:00	\N	ANCIEN	\N	\N	\N	\N	67	\N	\N
2903	MEMBRECOM	1986-10-06 00:00:00	1988-06-29 00:00:00	\N	ANCIEN	\N	\N	\N	\N	2134	\N	\N
2904	MEMBRECOM	1988-06-29 00:00:00	1989-10-04 00:00:00	\N	ANCIEN	\N	\N	\N	\N	2135	\N	\N
2525	VICPDTCOM	2003-07-15 00:00:00	2004-04-30 00:00:00	\N	ANCIEN	\N	\N	\N	\N	1916	\N	\N
2931	MEMBRECOM	1998-10-06 00:00:00	2000-04-27 00:00:00	\N	ANCIEN	\N	\N	\N	\N	67	\N	\N
3036	VICPDTCOM	1995-10-05 00:00:00	1997-01-29 00:00:00	\N	ANCIEN	\N	\N	\N	\N	289	\N	\N
3977	MEMBRECOM	1986-10-02 00:00:00	1995-10-04 00:00:00	\N	ANCIEN	\N	\N	\N	\N	289	\N	\N
4967	VICPDTCOM	2008-07-10 00:00:00	2008-07-17 00:00:00	\N	ANCIEN	\N	\N	\N	\N	4052	\N	\N
4586	MEMBRECOM	2007-07-05 00:00:00	2007-08-02 00:00:00	\N	ANCIEN	\N	\N	\N	\N	3668	\N	\N
3281	MEMBRECOM	2004-10-01 00:00:00	2004-10-06 00:00:00	\N	ANCIEN	\N	\N	\N	\N	2429	\N	\N
3333	MEMBRECOM	2004-10-01 00:00:00	2004-10-05 00:00:00	\N	ANCIEN	\N	\N	\N	\N	2483	\N	\N
3383	MEMBRECOM	2004-10-06 00:00:00	2008-10-07 00:00:00	\N	ANCIEN	\N	\N	\N	\N	2532	\N	\N
3418	MEMBRECOM	2004-10-06 00:00:00	2008-10-06 00:00:00	\N	ANCIEN	\N	\N	\N	\N	2567	\N	\N
4921	MEMBRECOM	2008-06-18 00:00:00	2008-07-23 00:00:00	\N	ANCIEN	\N	\N	\N	\N	4009	\N	\N
4925	MEMBRECOM	2008-06-18 00:00:00	2008-07-23 00:00:00	\N	ANCIEN	\N	\N	\N	\N	4013	\N	\N
5037	MEMBRECOM	2007-10-02 00:00:00	2008-10-01 00:00:00	\N	ANCIEN	\N	\N	\N	\N	289	\N	\N
4460	MEMBRECOM	2007-02-01 00:00:00	2007-02-13 00:00:00	\N	ANCIEN	\N	\N	\N	\N	3542	\N	\N
4761	MEMBRECOM	2007-12-14 00:00:00	2007-12-18 00:00:00	\N	ANCIEN	\N	\N	\N	\N	3846	\N	\N
8575	MEMBRECOM	2009-12-22 00:00:00	\N	\N	ACTIF	\N	\N	\N	\N	7127	\N	\N
1183	PDTCOM	2001-10-04 00:00:00	2004-04-30 00:00:00	\N	ANCIEN	\N	\N	\N	\N	289	\N	\N
5356	SECRETCOM	2008-10-08 00:00:00	2011-09-30 00:00:00	7	ANCIEN	\N	\N	\N	\N	2532	\N	\N
7884	SECRETCOM	2008-10-15 00:00:00	2009-06-30 00:00:00	\N	ANCIEN	\N	\N	\N	\N	6455	\N	\N
5320	MEMBRECOM	2011-10-01 00:00:00	2014-09-30 00:00:00	\N	ANCIEN	\N	\N	\N	\N	4344	\N	2014-10-01 19:54:29
4386	MEMBRECOM	2007-01-10 00:00:00	2007-07-11 00:00:00	\N	ANCIEN	\N	\N	\N	\N	3467	\N	\N
5195	MEMBRECOM	2008-10-07 00:00:00	2009-07-20 00:00:00	\N	ANCIEN	\N	\N	\N	\N	4273	\N	\N
4979	MEMBRECOM	2008-07-10 00:00:00	2008-07-17 00:00:00	\N	ANCIEN	\N	\N	\N	\N	4064	\N	\N
9210	MEMBRECOM	2011-02-10 00:00:00	\N	\N	ACTIF	\N	\N	\N	\N	7708	\N	\N
8724	PDTCOM	2010-03-31 00:00:00	2010-07-09 00:00:00	\N	ANCIEN	\N	\N	\N	\N	7234	\N	\N
8138	MEMBRECOM	2009-04-02 00:00:00	2009-04-07 00:00:00	\N	ANCIEN	\N	\N	\N	\N	6712	\N	\N
7982	MEMBRECOM	2009-01-21 00:00:00	2009-01-28 00:00:00	\N	ANCIEN	\N	\N	\N	\N	6550	\N	\N
8706	MEMBRECOM	2010-03-30 00:00:00	2010-03-30 00:00:00	\N	ANCIEN	\N	\N	\N	\N	7234	\N	\N
8340	MEMBRECOM	2009-07-21 00:00:00	2010-01-07 00:00:00	\N	ANCIEN	\N	\N	\N	\N	6898	\N	\N
9717	SECRETCOM	2011-10-01 00:00:00	2012-02-20 00:00:00	\N	ANCIEN	\N	\N	\N	\N	2532	\N	\N
10390	SECRETCOM	2012-02-21 00:00:00	2014-10-07 00:00:00	\N	ANCIEN	\N	\N	\N	\N	8742	\N	2014-10-08 17:35:30
9596	SECRETCOM	2011-10-01 00:00:00	2012-07-21 00:00:00	\N	ANCIEN	\N	\N	\N	\N	8086	\N	\N
11024	MEMBRECOM	2013-04-23 00:00:00	2013-10-09 00:00:00	\N	ANCIEN	\N	\N	\N	\N	9311	\N	2013-12-16 10:30:09
11490	MEMBRECOM	2013-11-19 00:00:00	2014-09-30 00:00:00	\N	ANCIEN	\N	\N	\N	\N	9716	2013-11-19 18:46:16	2014-11-18 11:50:10
11765	MEMBRECOM	2014-06-18 00:00:00	2014-10-08 00:00:00	\N	ANCIEN	\N	\N	\N	\N	9948	2014-06-19 09:34:29	2014-10-09 16:15:58
11770	MEMBRECOM	2014-06-18 00:00:00	2015-01-17 00:00:00	\N	ANCIEN	\N	\N	\N	\N	9953	2014-06-19 09:35:09	2015-04-07 18:21:18
11911	MEMBRECOM	2014-10-03 00:00:00	2023-10-01 00:00:00	\N	ANCIEN	\N	\N	\N	\N	10079	2014-10-03 00:00:00	\N
12025	MEMBRECOM	2014-10-08 00:00:00	2017-10-03 00:00:00	\N	ANCIEN	\N	\N	\N	\N	10193	2014-10-08 17:35:29	2017-10-04 18:35:58
11742	MEMBRECOM	2014-05-05 00:00:00	2014-05-06 00:00:00	\N	ANCIEN	\N	\N	\N	\N	9924	2014-05-05 10:40:21	2014-05-07 12:20:13
11748	MEMBRECOM	2014-05-07 00:00:00	2014-10-08 00:00:00	\N	ANCIEN	\N	\N	\N	\N	9930	2014-05-07 12:20:13	2014-10-09 13:57:49
12268	SECRETCOM	2014-10-09 00:00:00	2017-10-04 00:00:00	2	ANCIEN	\N	\N	\N	\N	9930	2014-10-09 13:57:48	2017-10-04 18:49:33
13774	MEMBRECOM	2015-09-08 00:00:00	\N	\N	ACTIF	\N	\N	\N	\N	11630	\N	\N
14632	SECRETCOM	2016-06-28 00:00:00	2016-07-07 00:00:00	\N	ANCIEN	\N	\N	\N	\N	12376	2016-06-28 19:42:13	2016-07-07 16:33:43
14548	MEMBRECOM	2016-06-22 00:00:00	2016-06-27 00:00:00	\N	ANCIEN	\N	\N	\N	\N	12376	2016-06-22 16:29:30	2016-06-28 19:42:13
14315	MEMBRECOM	2016-04-27 00:00:00	2016-10-14 00:00:00	\N	ANCIEN	\N	\N	\N	\N	12168	2016-04-27 15:15:54	2017-06-12 11:08:26
14684	MEMBRECOM	2016-07-07 00:00:00	2017-06-12 00:00:00	\N	ANCIEN	\N	\N	\N	\N	12488	2016-07-07 17:26:07	2017-06-12 11:07:18
16622	MEMBRECOM	2018-02-07 00:00:00	2018-07-07 00:00:00	\N	ANCIEN	\N	\N	\N	\N	13909	2018-02-06 16:33:28	\N
15835	MEMBRECOM	2017-10-04 00:00:00	2023-10-01 00:00:00	\N	ANCIEN	\N	\N	\N	\N	10193	2017-10-04 00:00:00	\N
16222	VICPDTCOM	2017-10-05 00:00:00	2018-11-13 00:00:00	4	ANCIEN	\N	\N	\N	\N	9930	2017-10-05 14:46:17	2017-10-05 14:46:41
16963	MEMBRECOM	2018-06-19 00:00:00	2018-06-20 00:00:00	\N	ANCIEN	\N	\N	\N	\N	14232	\N	\N
17367	MEMBRECOM	2018-11-14 00:00:00	2020-10-06 00:00:00	\N	ANCIEN	\N	\N	\N	\N	9930	\N	\N
23831	MEMBRECOM	2024-06-05 00:00:00	2024-11-11 00:00:00	\N	ANCIEN	\N	\N	\N	\N	19818	\N	\N
22585	VICPDTCOM	2023-10-05 00:00:00	2026-09-30 00:00:00	\N	ANCIEN	\N	\N	\N	\N	18383	\N	2026-09-30 15:12:05
23012	MEMBRECOM	2023-12-18 00:00:00	2023-12-19 00:00:00	\N	ANCIEN	\N	\N	\N	\N	19124	\N	\N
22803	MEMBRECOM	2021-06-24 00:00:00	2021-06-25 00:00:00	\N	ANCIEN	\N	\N	\N	\N	18959	\N	\N
22063	MEMBRECOM	2023-10-04 00:00:00	2023-10-04 00:00:00	\N	ANCIEN	\N	\N	\N	\N	18383	\N	\N
21685	MEMBRECOM	2023-10-02 00:00:00	2023-10-03 00:00:00	\N	ANCIEN	\N	\N	\N	\N	18007	2023-09-24 00:00:00	\N
19377	SECRETCOM	2020-10-07 00:00:00	2023-10-01 00:00:00	\N	ANCIEN	\N	\N	\N	\N	9930	\N	\N
22245	MEMBRECOM	2023-10-04 00:00:00	2024-10-21 00:00:00	\N	ANCIEN	\N	\N	\N	\N	18565	\N	\N
21961	MEMBRECOM	2023-10-02 00:00:00	2023-10-03 00:00:00	\N	ANCIEN	\N	\N	\N	\N	18281	2023-10-03 00:00:00	\N
24859	MEMBRECOM	2023-10-02 00:00:00	\N	\N	ACTIF	\N	\N	\N	\N	20676	2025-06-03 11:00:19	2025-06-03 11:00:19
27000	MEMBRECOM	2026-10-06 00:00:00	\N	\N	ACTIF	\N	\N	\N	\N	22630	2026-10-06 17:52:02	2026-10-06 17:52:02
27025	MEMBRECOM	2026-10-06 00:00:00	\N	\N	ACTIF	\N	\N	\N	\N	22655	2026-10-06 17:52:04	2026-10-06 17:52:04
25588	MEMBRECOM	2025-11-13 00:00:00	2025-11-13 00:00:00	\N	ANCIEN	\N	\N	\N	\N	21375	2025-11-12 15:21:55	2025-11-13 14:42:42
27484	VICPDTCOM	2026-10-27 00:00:00	\N	2	ACTIF	\N	\N	\N	\N	22947	2026-10-27 15:59:45	2026-10-27 16:55:25
23960	VICPDTCOM	2024-11-12 00:00:00	2026-09-30 00:00:00	\N	ANCIEN	\N	\N	\N	\N	19818	\N	2026-09-30 15:09:04
26624	MEMBRECOM	2026-10-01 00:00:00	2026-10-05 00:00:00	\N	ANCIEN	\N	\N	\N	\N	22254	2026-09-30 15:12:05	2026-10-06 17:52:04
25594	MEMBRECOM	2025-11-14 00:00:00	2026-09-30 00:00:00	\N	ANCIEN	\N	\N	\N	\N	21379	2025-11-13 14:42:42	2026-09-27 19:26:47
26147	MEMBRECOM	2026-06-22 00:00:00	2026-06-24 00:00:00	\N	ANCIEN	\N	\N	\N	\N	21813	2026-06-22 15:10:12	2026-07-02 10:11:25
26420	MEMBRECOM	2026-10-01 00:00:00	2026-10-05 00:00:00	\N	ANCIEN	\N	\N	\N	\N	22050	2026-09-27 19:26:47	2026-10-06 17:52:02
27458	MEMBRECOM	2026-10-21 00:00:00	2026-10-26 00:00:00	\N	ANCIEN	\N	\N	\N	\N	22947	2026-10-21 11:53:21	2026-10-27 15:59:45
\.

COPY fonmemgrppol (fonmemgrppolid, fongrppolcod, fonmemgrppoldatdeb, fonmemgrppoldatfin, temvalcod, evelic, evelib, evelil, eveobs, memgrppolid, syscredat, sysmajdat) FROM stdin;
290	MEMBREPOL	\N	2002-12-10 00:00:00	ANCIEN	\N	\N	\N	\N	290	\N	\N
711	MEMBREPOL	2002-12-11 00:00:00	2004-04-30 00:00:00	ANCIEN	\N	\N	\N	\N	715	\N	\N
67	MEMBREPOL	\N	2000-04-27 00:00:00	ANCIEN	\N	\N	\N	\N	67	\N	\N
2154	MEMBREPOL	2007-10-01 00:00:00	2023-10-01 00:00:00	ANCIEN	\N	\N	\N	\N	1875	\N	\N
1914	MEMBREPOL	2004-10-01 00:00:00	2004-10-07 00:00:00	ANCIEN	\N	\N	\N	\N	1649	\N	\N
1964	MEMBREPOL	2004-10-01 00:00:00	2008-11-27 00:00:00	ANCIEN	\N	\N	\N	\N	1702	\N	\N
2040	MEMBREPOL	2004-10-05 00:00:00	2011-09-30 00:00:00	ANCIEN	\N	\N	\N	\N	1776	\N	\N
2354	MEMBREPOL	2008-11-28 00:00:00	2010-01-07 00:00:00	ANCIEN	\N	\N	\N	\N	2081	\N	\N
2502	MEMBREPOL	2011-10-01 00:00:00	2012-07-21 00:00:00	ANCIEN	\N	\N	\N	\N	2228	\N	\N
2609	MEMBREPOL	2011-10-01 00:00:00	2012-11-09 00:00:00	ANCIEN	\N	\N	\N	\N	2328	\N	\N
2709	MEMBREPOL	2012-11-07 00:00:00	2014-10-06 00:00:00	ANCIEN	\N	\N	\N	\N	2386	\N	2014-10-07 15:49:04
2738	MEMBREPOL	2014-05-05 00:00:00	2023-10-01 00:00:00	ANCIEN	\N	\N	\N	\N	2421	2014-05-05 00:00:00	\N
2903	PDTPOL	2014-10-07 00:00:00	2024-09-30 00:00:00	ANCIEN	\N	\N	\N	\N	2386	2014-10-07 00:00:00	\N
4104	MEMBREPOL	2024-10-01 00:00:00	2024-10-21 00:00:00	ANCIEN	\N	\N	\N	\N	2386	\N	\N
3973	MEMBREPOL	2023-10-03 00:00:00	\N	ACTIF	\N	\N	\N	\N	3551	\N	\N
3852	MEMBREPOL	2023-10-02 00:00:00	2023-10-02 00:00:00	ANCIEN	\N	\N	\N	\N	3431	2023-09-24 00:00:00	\N
3754	MEMBREPOL	2023-10-02 00:00:00	2023-10-02 00:00:00	ANCIEN	\N	\N	\N	\N	3333	2023-09-24 00:00:00	\N
3928	MEMBREPOL	2023-10-03 00:00:00	\N	ACTIF	\N	\N	\N	\N	3507	\N	\N
4190	MEMBREPOL	2025-11-13 00:00:00	2026-09-30 00:00:00	ANCIEN	\N	\N	\N	\N	3767	2025-11-12 15:22:34	2026-09-27 19:26:47
4587	MEMBREPOL	2026-10-05 00:00:00	\N	ACTIF	\N	\N	\N	\N	4157	2026-10-05 16:49:30	2026-10-05 16:59:27
4322	MEMBREPOL	2026-10-01 00:00:00	2026-10-04 00:00:00	ANCIEN	\N	\N	\N	\N	3899	2026-09-27 19:26:47	2026-10-05 16:49:30
\.

COPY grppol (grppolcod, grppolpre, grppoldatcre, grppoldatfin, grppolliccou, grppollibcou, grppollilcou, temvalcod, evelic, evelib, evelil, typorgcod, grppolart, grppolurlsim, grppolurlcmp, grppolcodamelicou, syscredat, sysmajdat) FROM stdin;
CRC	OUI	2011-10-01 00:00:00	\N	CRCE-K	Groupe CRCE - Kanaky	Groupe Communiste Républicain Citoyen et Écologiste - Kanaky	ACTIF	\N	\N	\N	GRPPOL	du	\N	https://senateurscrce.fr	CRCE	\N	2026-10-05 17:46:38
NI	NON	1899-12-31 00:00:00	\N	NI	Réunion administrative des non-inscrits	Réunion administrative des Sénateurs ne figurant sur la liste d'aucun groupe	ACTIF	\N	\N	\N	GRPPOLNI	de la	\N	https://rasnag-senat.fr/	NI	\N	2026-10-05 17:48:47
RDSE	OUI	1899-12-31 00:00:00	\N	RDSE	Groupe du RDSE	Groupe du Rassemblement Démocratique et Social Européen	ACTIF	\N	\N	\N	GRPPOL	du	\N	http://www.rdse-senat.fr	RDSE	\N	2026-10-05 17:46:58
RI	OUI	1900-01-01 00:00:00	2002-12-10 00:00:00	RI	Groupe des RI	Groupe des Républicains et Indépendants	ANCIEN	\N	\N	\N	GRPPOL	du	\N	http://www.senat.fr/grp/ri/index.html	RI	\N	2014-02-14 17:27:30
RPR	OUI	1900-01-01 00:00:00	2002-12-10 00:00:00	RPR	Groupe du RPR	Groupe du Rassemblement pour la République	ANCIEN	\N	\N	\N	GRPPOL	du	\N	http://www.rpr-senat.org	RPR	\N	2014-02-14 17:27:30
SOC	OUI	2015-06-11 00:00:00	\N	SER	Groupe Socialiste, Écologiste et Républicain	Groupe Socialiste, Écologiste et Républicain	ACTIF	\N	\N	\N	GRPPOL	du	\N	http://www.senateurs-socialistes.fr/	SOC	\N	2026-10-05 17:46:03
UC	OUI	2008-10-02 00:00:00	\N	UCI	Groupe Union Centriste et Indépendants	Groupe Union Centriste et Indépendants	ACTIF	\N	\N	\N	GRPPOL	du 	\N	http://unioncentriste-senat.fr/	UCI	\N	2026-10-05 17:45:39
AUCUN	NON	1899-12-31 00:50:39	\N	Aucun	Sénateurs n'appartenant à aucun groupe	Nouveaux Sénateurs	ACTIF	\N	\N	\N	GRPPOL	de la	\N	\N	AUCUN	\N	2014-01-02 15:39:01
UMP	OUI	2002-12-11 00:00:00	\N	Les Républicains	Groupe Les Républicains	Groupe Les Républicains	ACTIF	\N	\N	\N	GRPPOL	du	\N	http://www.lesrepublicains-senat.fr/	REPUBLICAINS	\N	2017-10-09 16:22:46
C	OUI	1900-01-01 00:00:00	1995-10-01 00:00:00	C	Communistes	Groupe Communiste	ANCIEN	\N	\N	\N	GRPPOL	du	\N	\N	C	\N	2014-10-02 09:56:55
CNIP	OUI	1900-01-01 00:00:00	1980-10-01 00:00:00	C.N.I.P.	Centre National des Indépendants et Paysans	Groupe du Centre National des Indépendants et Paysans	ANCIEN	\N	\N	\N	GRPPOL	du	\N	\N	C.N.I.P.	\N	2014-10-02 09:56:55
CRARS	OUI	1900-01-01 00:00:00	1980-10-01 00:00:00	CRARS	Centre Républicain d'Action Rurale et Sociale	Groupe du Centre Républicain d'Action Rurale et Sociale	ANCIEN	\N	\N	\N	GRPPOL	du	\N	\N	CRARS	\N	2014-10-02 09:56:55
FCD	OUI	1900-01-01 00:00:00	1968-10-01 00:00:00	FCD	Formation Centre Démocratique (rattaché R.P.)	Groupe de la Formation Centre Démocratique (rattaché R.P.)	ANCIEN	\N	\N	\N	GRPPOL	du	\N	\N	FCD	\N	2014-10-02 09:56:55
GD	OUI	1900-01-01 00:00:00	1989-10-01 00:00:00	G.D.	Gauche Démocratique	Groupe de la Gauche Démocratique	ANCIEN	\N	\N	\N	GRPPOL	du	\N	\N	G.D.	\N	2014-10-02 09:56:55
GDSRG	OUI	1900-01-01 00:00:00	1986-10-01 00:00:00	G.D.S.R.G.	Formation des Sénateurs Radicaux de Gauche	Formation des Sénateurs Radicaux de Gauche rattachée administrativement au groupe de la Gauche Démocratique	ANCIEN	\N	\N	\N	GRPPOL	de la	\N	\N	G.D.S.R.G.	\N	2014-10-02 09:56:55
MRP	OUI	1900-01-01 00:00:00	1959-04-29 00:00:00	MRP	Mouvement Républicain Populaire	Groupe du Mouvement Républicain Populaire	ANCIEN	\N	\N	\N	GRPPOL	du	\N	\N	MRP	\N	2014-10-02 09:56:55
RDE	OUI	1899-12-31 00:50:39	1995-10-02 00:00:00	R.D.E.	Rassemblement Démocratique et Européen	Groupe du Rassemblement Démocratique et Européen	ANCIEN	\N	\N	\N	GRPPOL	du	\N	\N	R.D.E.	\N	2014-10-02 09:56:55
RIAS	OUI	1900-01-01 00:00:00	1980-10-01 00:00:00	R.I.A.S.	Républicains Indépendants d'Action Sociale (Devenu C.N.I.P.)	Groupe des Républicains Indépendants d'Action Sociale	ANCIEN	\N	\N	\N	GRPPOL	du	\N	\N	R.I.A.S.	\N	2014-10-02 09:56:55
RP	OUI	1900-01-01 00:00:00	1968-10-01 00:00:00	RP	Républicains Populaires	Groupe des Républicains Populaires	ANCIEN	\N	\N	\N	GRPPOL	du	\N	\N	RP	\N	2014-10-02 09:56:55
RPCD	OUI	1900-01-01 00:00:00	1974-10-01 00:00:00	RPCD	Républicains Populaires et du Centre Démocratique	Groupe des Républicains Populaires et du Centre Démocratique	ANCIEN	\N	\N	\N	GRPPOL	du	\N	\N	RPCD	\N	2014-10-02 09:56:55
UCDP	OUI	1900-01-01 00:00:00	1986-10-01 00:00:00	U.C.D.P.	Union Centriste des Démocrates de Progrès	Groupe de l'Union Centriste des Démocrates de Progrès	ANCIEN	\N	\N	\N	GRPPOL	du	\N	\N	U.C.D.P.	\N	2014-10-02 09:56:55
UDR	OUI	1900-01-01 00:00:00	1977-10-01 00:00:00	U.D.R.	Union des Démocrates pour la République	Groupe de l'Union des Démocrates pour la République	ANCIEN	\N	\N	\N	GRPPOL	du	\N	\N	U.D.R.	\N	2014-10-02 09:56:55
UNR	OUI	1900-01-01 00:00:00	1968-10-01 00:00:00	U.N.R.	Union pour la Nouvelle République	Groupe de l'Union pour la Nouvelle République	ANCIEN	\N	\N	\N	GRPPOL	du	\N	\N	U.N.R.	\N	2014-10-02 09:56:55
UREI	OUI	1900-01-01 00:00:00	2004-10-01 00:00:00	U.R.E.I.	Union des Républicains et des Indépendants	Groupe de l'Union des Républicains et des Indépendants	ANCIEN	\N	\N	\N	GRPPOL	du	\N	\N	U.R.E.I.	\N	2014-10-02 09:56:55
ECO	OUI	2012-01-11 00:00:00	2017-06-29 00:00:00	Écologiste	Groupe écologiste	Groupe écologiste	ANCIEN	\N	\N	\N	GRPPOL	du 	\N	http://ecologistes-senat.fr/	ECOLO	\N	2017-06-30 09:52:10
LREM	NON	2017-06-28 00:00:00	\N	RDPI	Groupe Rassemblement des démocrates, progressistes et indépendants	Groupe Rassemblement des démocrates, progressistes et indépendants	ACTIF	\N	\N	\N	GRPPOL	du	\N	\N	LaREM	2017-06-29 09:48:06	2026-10-05 17:47:22
RTLI	NON	2020-10-05 00:00:00	\N	Les Indépendants	Groupe Les Indépendants - République et Territoires	Groupe Les Indépendants - République et Territoires	ACTIF	\N	\N	\N	GRPPOL	du	\N	\N	RTLI	2017-10-03 00:00:00	2026-10-05 17:48:17
GEST	OUI	2020-10-05 00:00:00	\N	GEST	Groupe Écologiste - Solidarité et Territoires	Groupe Écologiste - Solidarité et Territoires	ACTIF	\N	\N	\N	GRPPOL	du	\N	\N	GEST	\N	2026-10-05 17:47:58
UNT	OUI	2026-10-05 00:00:00	\N	UNT	Groupe Union Nationale pour les Territoires	Groupe Union Nationale pour les Territoires	ACTIF	\N	\N	\N	GRPPOL	du	\N	\N	UNT	2026-10-05 15:36:44	2026-10-05 18:12:17
\.

COPY libcom (orgcod, libcomdatdeb, libcomdatfin, temvalcod, evelic, evelib, evelil, libcomart, libcomlilmin, libcomlibameli, syscredat, sysmajdat, libcomid) FROM stdin;
NEANT	1900-01-01 00:00:00	\N	ACTIF	Aucune	                     	Aucune  (Président du Sénat)	d'	Aucune  (Président du Sénat)	Aucune (Président du Sénat)	\N	\N	35
SOCI	1900-01-01 00:00:00	\N	ACTIF	SOCI	Affaires sociales	COMMISSION DES AFFAIRES SOCIALES	de la 	commission des affaires sociales	commission des affaires sociales	\N	\N	36
20030515N2	2003-05-15 00:00:00	\N	\N	\N	Urbanisme, habitat et construction	\N	du	projet de loi portant diverses dispositions relatives à l'urbanisme, à l'habitat et à la construction	\N	\N	\N	51
INITIATIVE	2003-02-12 00:00:00	2003-07-21 00:00:00	ANCIEN	INITIATIVE ÉCONOMIQUE	COMMISSION SPÉCIALE "INITIATIVE ÉCONOMIQUE"	COMMISSION SPÉCIALE CHARGÉE D'EXAMINER LE PROJET DE LOI POUR L'INITIATIVE ÉCONOMIQUE	de la	commission spéciale chargée d'examiner le projet de loi pour l'initiative économique	Commission spéciale	\N	\N	53
20030715N6	2003-07-15 00:00:00	\N	\N	\N	prévention des risques technologiques et naturels	\N	du	projet de loi relatif à la prévention des risques technologiques et naturels et à la réparation des dommages	\N	\N	\N	56
ECON	2009-06-25 00:00:00	2012-02-20 00:00:00	ACTIF	ECON	Économie	COMMISSION DE L'ÉCONOMIE, DU DÉVELOPPEMENT DURABLE ET DE L'AMÉNAGEMENT DU TERRITOIRE	de la 	commission de l'économie, du développement durable et de l'aménagement du territoire	commission de l'économie	\N	\N	112
SERVICE	2007-07-05 00:00:00	2007-08-02 00:00:00	ANCIEN	Service minimum	Commission spéciale sur le service minimum	COMMISSION SPECIALE SUR LE PROJET DE LOI RELATIF AU SERVICE MINIMUM	de la	Commission spéciale sur le projet de loi relatif au service minimum	Commission spéciale	\N	\N	117
2007CMP3	2007-02-01 00:00:00	2007-02-13 00:00:00	\N	\N	modernisation de la diffusion audiovisuelle et à la télévisi	\N	du	projet de loi relatif à la modernisation de la diffusion audiovisuelle et à la télévision du futur	\N	\N	\N	133
COLLECTIVITE	2008-10-15 00:00:00	2009-06-30 00:00:00	ANCIEN	Mission collectivités	Mission temporaire collectivités territoriales	MISSION TEMPORAIRE SUR L'ORGANISATION ET L'EVOLUTION DES COLLECTIVITÉS TERRITORIALES	de la	Mission temporaire sur l'organisation et l'évolution des collectivités territoriales	Mission temporaire collectivités territoriales	\N	\N	141
2009CMP6	2009-04-02 00:00:00	2009-04-07 00:00:00	\N	\N	diffusion et  protection de la création sur internet	\N	du	projet de loi favorisant la diffusion et la protection de la création sur internet	\N	\N	\N	147
XYNTHIA	2010-03-30 00:00:00	2010-07-09 00:00:00	ACTIF	Tempête Xynthia	Mission commune d'information sur les conséquences de la tempête Xynthia	MISSION COMMUNE D'INFORMATION SUR LES CONSÉQUENCES DE LA TEMPÊTE XYNTHIA	de la	Mission commune d'information sur les conséquences de la tempête Xynthia	Mission commune d'information sur les conséquences de la tempête Xynthia	\N	\N	150
2009CMP1	2009-01-21 00:00:00	2009-01-28 00:00:00	\N	\N	Communication audiovisuelle et service public de la télévisi	\N	du	projet de loi relatif à la communication audiovisuelle et au nouveau service public de la télévision	\N	\N	\N	29
FORMATION	2007-01-10 00:00:00	2007-07-11 00:00:00	ACTIF	MCI FORMATION	Mission commune d'information "Formation professionnelle"	MISSION COMMUNE D'INFORMATION SUR LE FONCTIONNEMENT DES DISPOSITIFS DE FORMATION PROFESSIONNELLE	de la 	Mission commune d'information sur le fonctionnement des dispositifs de formation professionnelle	Mission commune d'information "Formation professionnelle"	\N	2015-01-14 10:41:18	6
2007CMP16	2007-12-14 00:00:00	2007-12-18 00:00:00	\N	\N	développement de la concurrence au service des consommateurs	\N	du	projet de loi pour le développement de la concurrence au service des consommateurs	\N	\N	\N	17
2008CMP9	2008-07-10 00:00:00	2008-07-17 00:00:00	\N	\N	modernisation de l'économie	\N	du	projet de loi de modernisation de l'économie	\N	\N	\N	21
ECONOMIE	2008-06-18 00:00:00	2008-07-23 00:00:00	ANCIEN	Modernisation de l'économie	Commission spéciale sur la modernisation de l'économie	COMMISSION SPÉCIALE SUR LE PROJET DE LOI DE MODERNISATION DE L'ÉCONOMIE	de la	Commission spéciale sur le projet de loi de modernisation de l'économie	Commission spéciale modernisation de l'économie	\N	\N	24
AFCL	1899-12-31 00:00:00	2023-10-04 00:00:00	ANCIEN	AFCL	Affaires culturelles	COMMISSION DES AFFAIRES CULTURELLES	de la 	commission des affaires culturelles	Commission des Affaires culturelles	\N	2023-10-04 00:00:00	30
ECON	1900-01-01 00:00:00	2009-06-25 00:00:00	ANCIEN	ECON	Affaires économiques	COMMISSION DES AFFAIRES ECONOMIQUES	de la 	commission des affaires économiques	Commission des Affaires économiques	\N	\N	31
ETRD	1900-01-01 00:00:00	\N	ACTIF	ETRD	Affaires étrangères	COMMISSION DES AFFAIRES ÉTRANGÈRES, DE LA DÉFENSE ET DES FORCES ARMÉES	de la 	commission des affaires étrangères, de la défense et des forces armées	commission des affaires étrangères	\N	\N	32
CAE	2012-02-21 00:00:00	\N	ACTIF	CAE	Affaires économiques	COMMISSION DES AFFAIRES ÉCONOMIQUES	de la 	commission des affaires économiques	commission des affaires économiques	\N	2014-01-31 14:47:01	163
DECE	2013-04-23 00:00:00	2013-10-09 00:00:00	ACTIF	MCI Organisation décentralisée 	Mission commune d'information sur l'avenir de l'organisation décentralisée de la République	MISSION COMMUNE D'INFORMATION SUR L'AVENIR DE L'ORGANISATION DÉCENTRALISÉE DE LA RÉPUBLIQUE	de la	Mission commune d'information sur l'avenir de l'organisation décentralisée de la République	Mission commune d'information sur l'avenir de l'organisation décentralisée de la République	2013-04-23 18:22:31	2014-04-14 14:34:45	241
TURQUIE	2016-04-27 00:00:00	2016-10-14 00:00:00	ACTIF	MI Accord UE/Turquie	Mission d'information sur l'accord de mars 2016 entre l'Union européenne et la Turquie relatif à la crise des réfugiés	Mission d'information sur la position de la France à l'égard de l'accord de mars 2016 entre l'Union européenne et la Turquie relatif à la crise des réfugiés et sur les conditions de mise en oeuvre de cet accord	de la	mission d'information sur la position de la France à l'égard de l'accord de mars 2016 entre l'Union européenne et la Turquie relatif à la crise des réfugiés et sur les conditions de mise en oeuvre de cet accord	mission d'information sur l'accord UE/Turquie relatif à la crise des réfugiés	2016-04-27 15:03:19	2017-06-12 11:08:26	842
CITOYENNETE	2016-06-22 00:00:00	2016-07-07 00:00:00	ACTIF	GT Egalité et citoyenneté	Groupe de travail préfigurant commission spéciale Egalité et citoyenneté	GT PREFIGURANT COMMISSION SPECIALE EGALITE ET CITOYENNETE	de la	groupe de travail préfigurant commission spéciale "égalité et citoyenneté"	Groupe de travail préfigurant commission spéciale Egalité et citoyenneté	2016-06-22 16:05:02	2017-03-21 11:14:04	1001
CHUTE	2018-02-07 00:00:00	2018-07-07 00:00:00	ACTIF	CE Moyens de l'Etat après chute Etat islamique	CE Moyens de l'Etat après chute Etat islamique	COMMISSION D'ENQUÊTE SUR L'ORGANISATION ET LES MOYENS DES SERVICES DE L'ETAT POUR FAIRE FACE À L'ÉVOLUTION DE LA MENACE TERRORISTE APRÈS LA CHUTE DE L'ETAT ISLAMIQUE	de la	Commission d'enquête sur l'organisation et les moyens des services de l'Etat pour faire face à l'évolution de la menace terroriste après la chute de l'Etat islamique	CE Moyens de l'Etat après chute Etat islamique	2018-02-06 16:26:47	2018-02-16 12:03:28	1762
GOUVERNANCE	2013-11-19 00:00:00	2014-09-30 00:00:00	ACTIF	MCI sur la gouvernance de l'internet	Mission commune d'information sur la gouvernance de l'internet	MISSION COMMUNE D'INFORMATION SUR LE NOUVEAU RÔLE ET LA NOUVELLE STRATÉGIE POUR L'UNION EUROPÉENNE DANS LA GOUVERNANCE DE L'INTERNET	de la 	Mission commune d'information sur le nouveau rôle et la nouvelle stratégie pour l'Union européenne dans la gouvernance de l'internet	Mission commune d'information sur le nouveau rôle et la nouvelle stratégie pour l'UE dans la gouvernance de l'internet	2013-11-19 18:41:46	2014-11-18 15:40:46	321
REGIONS	2014-06-18 00:00:00	2015-01-17 00:00:00	ACTIF	CS Délimitation des régions	Commission spéciale Délimitation des régions, élections régionales et départementales et calendrier électoral	COMMISSION SPÉCIALE CHARGÉE D'EXAMINER LE PROJET DE LOI RELATIF À LA DÉLIMITATION DES RÉGIONS, AUX ÉLECTIONS RÉGIONALES ET DÉPARTEMENTALES ET MODIFIANT LE CALENDRIER ÉLECTORAL	de la	Commission spéciale chargée d'examiner le projet de loi relatif à la délimitation des régions, aux élections régionales et départementales et modifiant le calendrier électoral	Commission spéciale Délimitation des régions, élections régionales et départementales et calendrier électoral	2014-06-18 21:50:55	2015-04-09 17:09:52	421
EGALITE	2016-07-07 00:00:00	2017-06-12 00:00:00	ACTIF	CS Egalité et citoyenneté	Commission spéciale chargée d'examiner le projet de loi « Egalité et citoyenneté »	COMMISSION SPÉCIALE CHARGÉE D¿EXAMINER LE PROJET DE LOI « ÉGALITÉ ET CITOYENNETÉ »	de la	commission spéciale chargée d'examiner le projet de loi « Égalité et citoyenneté »	Commission spéciale chargée d'examiner le projet de loi « Egalité et citoyenneté »	2016-07-07 17:19:19	2017-06-12 11:07:18	1061
AFCL	2023-10-04 00:00:00	2024-01-17 00:00:00	ANCIEN	AFCL	Culture	COMMISSION DE LA CULTURE, DE L'ÉDUCATION ET DE LA COMMUNICATION	AFC	commission de la culture, de l'éducation et de la communication	commission de la culture	2023-10-04 00:00:00	2024-01-19 00:00:00	3641
INEG	2021-06-24 00:00:00	2021-06-25 00:00:00	ACTIF	INEG	PJL de programmation développement solidaire et lutte contre les inégalités mondiales	INEG	du	projet de loi de programmation relatif au développement solidaire et à la lutte contre les inégalités mondiales	INEG	\N	\N	3707
IMMI	2023-12-18 00:00:00	2023-12-19 00:00:00	ACTIF	IMMI	PJL Immigration	IMMI	du	projet de loi pour contrôler l'immigration, améliorer l'intégration	IMMI	\N	\N	3842
AFCL	2024-01-18 00:00:00	\N	ACTIF	AFCL	Culture	COMMISSION DE LA CULTURE, DE L'ÉDUCATION, DE LA COMMUNICATION ET DU SPORT	de la	commission de la culture, de l'éducation, de la communication et du sport	commission de la culture	2024-01-19 00:00:00	\N	3883
CYBE	2024-06-05 00:00:00	\N	ACTIF	CS Cybersécurité	CS Cybersécurité	Projet de loi relatif à la résilience des infrastructures critiques et au renforcement de la cybersécurité	de la	projet de loi relatif à la résilience des infrastructures critiques et au renforcement de la cybersécurité	CS Cybersécurité	\N	2026-10-21 11:31:26	4201
LPMD	2026-06-22 00:00:00	2026-06-24 00:00:00	ACTIF	PJL Actualisation LPM 2024-2030	PJL Actualisation LPM 2024-2030	Projet de loi actualisant la programmation militaire pour les années 2024 à 2030 et portant diverses dispositions intéressant la défense	\N	projet de loi actualisant la programmation militaire pour les années 2024 à 2030 et portant diverses dispositions intéressant la défense	LPMD	2026-06-22 15:06:40	2026-07-02 10:11:25	5141
\.

COPY libgrppol (grppolcod, libgrppoldatdeb, libgrppoldatfin, temvalcod, evelic, evelib, evelil, eveobs, libgrppolart, libgrppolcodameli, syscredat, sysmajdat, libgrppolid) FROM stdin;
UC	2008-10-02 00:00:00	2011-09-30 00:00:00	\N	UC	Groupe UC	Groupe Union centriste	\N	du	UC	\N	\N	1
CRC	1899-12-31 00:50:39	2008-11-27 00:00:00	\N	Communiste républicain citoyen et écologiste	Groupe CRCE	Groupe communiste républicain citoyen et écologiste	\N	du	CRCE	\N	2017-10-03 16:48:10	2
NI	1899-12-31 00:50:39	\N	\N	NI	Réunion administrative des non-inscrits	Réunion administrative des Sénateurs ne figurant sur la liste d'aucun groupe	\N	de la	NI	\N	2017-06-29 10:05:29	3
RDSE	1899-12-31 00:00:00	\N	ACTIF	RDSE	Groupe du RDSE	Groupe du Rassemblement Démocratique et Social Européen	\N	du	RDSE	2023-10-11 16:00:23	2023-10-11 00:00:00	4
RI	1900-01-01 00:00:00	2002-12-10 00:00:00	\N	RI	Groupe des RI	Groupe des Républicains et Indépendants	\N	du	RI	\N	\N	5
RPR	1900-01-01 00:00:00	2002-12-10 00:00:00	\N	RPR	Groupe du RPR	Groupe du Rassemblement pour la République	\N	du	RPR	\N	\N	6
SOC	2020-10-05 00:00:00	\N	ACTIF	SER	Groupe Socialiste, Écologiste et Républicain	Groupe Socialiste, Écologiste et Républicain	\N	du	SOC	\N	\N	261
UC	1899-12-31 00:50:39	2005-01-13 00:00:00	\N	UC	Groupe Union Centriste	Groupe Union Centriste	\N	du	UC	\N	2017-07-05 10:13:38	8
AUCUN	1899-12-31 00:50:39	\N	\N	Aucun	Sénateurs n'appartenant à aucun groupe	Nouveaux Sénateurs	\N	de la	AUCUN	\N	\N	9
UMP	2002-12-11 00:00:00	2015-06-01 00:00:00	ANCIEN	UMP	Groupe UMP	Groupe Union pour un Mouvement Populaire	\N	du	UMP	\N	2026-04-17 16:16:47	10
C	1900-01-01 00:00:00	1995-10-01 00:00:00	\N	C	Communistes	Groupe Communiste	\N	du	C	\N	\N	11
CNIP	1900-01-01 00:00:00	1980-10-01 00:00:00	\N	C.N.I.P.	Centre National des Indépendants et Paysans	Groupe du Centre National des Indépendants et Paysans	\N	du	C.N.I.P.	\N	\N	12
CRARS	1900-01-01 00:00:00	1980-10-01 00:00:00	\N	CRARS	Centre Républicain d'Action Rurale et Sociale	Groupe du Centre Républicain d'Action Rurale et Sociale	\N	du	CRARS	\N	\N	13
FCD	1900-01-01 00:00:00	1968-10-01 00:00:00	\N	FCD	Formation Centre Démocratique (rattaché R.P.)	Groupe de la Formation Centre Démocratique (rattaché R.P.)	\N	du	FCD	\N	\N	14
GD	1900-01-01 00:00:00	1989-10-01 00:00:00	\N	G.D.	Gauche Démocratique	Groupe de la Gauche Démocratique	\N	du	G.D.	\N	\N	15
GDSRG	1900-01-01 00:00:00	1986-10-01 00:00:00	\N	G.D.S.R.G.	Formation des Sénateurs Radicaux de Gauche	Formation des Sénateurs Radicaux de Gauche rattachée administrativement au groupe de la Gauche Démocratique	\N	de la	G.D.S.R.G.	\N	\N	16
MRP	1900-01-01 00:00:00	1959-04-29 00:00:00	\N	MRP	Mouvement Républicain Populaire	Groupe du Mouvement Républicain Populaire	\N	du	MRP	\N	\N	17
RDE	1899-12-31 00:50:39	1995-10-02 00:00:00	\N	R.D.E.	Rassemblement Démocratique et Européen	Groupe du Rassemblement Démocratique et Européen	\N	du	R.D.E.	\N	\N	18
RIAS	1900-01-01 00:00:00	1980-10-01 00:00:00	\N	R.I.A.S.	Républicains Indépendants d'Action Sociale (Devenu C.N.I.P.)	Groupe des Républicains Indépendants d'Action Sociale	\N	du	R.I.A.S.	\N	\N	19
RP	1900-01-01 00:00:00	1968-10-01 00:00:00	\N	RP	Républicains Populaires	Groupe des Républicains Populaires	\N	du	RP	\N	\N	20
RPCD	1900-01-01 00:00:00	1974-10-01 00:00:00	\N	RPCD	Républicains Populaires et du Centre Démocratique	Groupe des Républicains Populaires et du Centre Démocratique	\N	du	RPCD	\N	\N	21
UCDP	1900-01-01 00:00:00	1986-10-01 00:00:00	\N	U.C.D.P.	Union Centriste des Démocrates de Progrès	Groupe de l'Union Centriste des Démocrates de Progrès	\N	du	U.C.D.P.	\N	\N	22
UDR	1900-01-01 00:00:00	1977-10-01 00:00:00	\N	U.D.R.	Union des Démocrates pour la République	Groupe de l'Union des Démocrates pour la République	\N	du	U.D.R.	\N	\N	23
UNR	1900-01-01 00:00:00	1968-10-01 00:00:00	\N	U.N.R.	Union pour la Nouvelle République	Groupe de l'Union pour la Nouvelle République	\N	du	U.N.R.	\N	\N	24
UREI	1900-01-01 00:00:00	2004-10-01 00:00:00	\N	U.R.E.I.	Union des Républicains et des Indépendants	Groupe de l'Union des Républicains et des Indépendants	\N	du	U.R.E.I.	\N	\N	25
UC	2005-01-14 00:00:00	2008-10-01 00:00:00	ANCIEN	UC	Groupe Union centriste	Groupe Union Centriste	\N	du	UC	\N	2017-07-04 10:59:59	26
CRC	2008-11-28 00:00:00	2011-09-30 00:00:00	\N	CRC-SPG	Groupe CRC-SPG	Groupe Communiste, Républicain, Citoyen et des Sénateurs du Parti de Gauche	\N	du	CRC-SPG	\N	\N	27
SOC	2011-10-01 00:00:00	2012-01-10 00:00:00	ANCIEN	SOC-EELVr	Groupe Socialiste, Apparentés et Groupe Europe Écologie	Groupe Socialiste, Apparentés et Groupe Europe Écologie Les Verts rattaché	\N	du	SOC-EELVr	\N	\N	28
UC	2011-10-01 00:00:00	2012-10-22 00:00:00	\N	UCR	Groupe UCR	Groupe de l'Union Centriste et Républicaine	\N	du	UCR	\N	\N	29
ECO	2012-01-11 00:00:00	2015-07-08 00:00:00	ANCIEN	ECOLO	Groupe écologiste	Groupe écologiste	\N	du 	ECOLO	\N	2015-07-09 15:25:01	30
CRC	2011-10-01 00:00:00	2015-07-08 00:00:00	ANCIEN	CRCE	Groupe CRCE	Groupe communiste républicain citoyen et écologiste	\N	du	CRCE	\N	2017-10-04 09:43:43	31
UC	2012-10-23 00:00:00	2017-07-03 00:00:00	ANCIEN	UDI-UC	Groupe UDI - UC	Groupe Union des Démocrates et Indépendants - UC	\N	du 	UDI-UC	\N	2017-07-04 10:56:52	32
RTLI	2020-10-05 00:00:00	2021-04-26 00:00:00	ANCIEN	INDEP	Groupe Les Indépendants - République et Territoires	Groupe Les Indépendants - République et Territoires	\N	du	RTLI	\N	\N	262
SOC	2015-06-11 00:00:00	2015-07-08 00:00:00	ANCIEN	SOC	Groupe socialiste et républicain	Groupe socialiste et républicain	\N	du	SOC	2015-06-11 09:52:33	2017-11-03 11:42:34	121
LREM	2020-10-05 00:00:00	\N	ACTIF	RDPI	Groupe Rassemblement des démocrates, progressistes et indépendants	Groupe Rassemblement des démocrates, progressistes et indépendants	\N	du	LaREM	\N	\N	263
GEST	2020-10-05 00:00:00	\N	ACTIF	GEST	Groupe Écologiste - Solidarité et Territoires	Groupe Écologiste - Solidarité et Territoires	\N	du	GEST	2023-10-11 16:04:02	2023-10-11 00:00:00	264
RTLI	2021-04-27 00:00:00	\N	ACTIF	Les Indépendants	Groupe Les Indépendants - République et Territoires	Groupe Les Indépendants - République et Territoires	\N	du	RTLI	\N	\N	301
CRC	2023-10-03 00:00:00	\N	ACTIF	CRCE-K	Groupe CRCE - Kanaky	Groupe Communiste Républicain Citoyen et Écologiste - Kanaky	\N	du	CRCE	2023-10-11 16:01:25	2023-10-11 00:00:00	321
SOC	1900-01-01 00:50:39	2011-09-30 00:00:00	ANCIEN	SOC	Groupe socialiste	Groupe socialiste	\N	du	SOC	2014-09-04 16:04:06	2015-07-09 16:27:01	41
SOC	2015-07-09 00:00:00	2020-10-04 00:00:00	ANCIEN	SOCR	Groupe socialiste et républicain	Groupe socialiste et républicain	\N	du	SOC	2015-07-09 15:24:16	2017-10-04 09:46:28	161
ECO	2015-07-09 00:00:00	2017-06-29 00:00:00	ACTIF	Écologiste	Groupe écologiste	Groupe écologiste	\N	du 	ECOLO	2015-07-09 15:25:01	2017-06-30 09:52:10	162
CRC	2015-07-09 00:00:00	2017-10-02 00:00:00	ANCIEN	Communiste républicain et citoyen	Groupe CRC	Groupe communiste républicain et citoyen	\N	du	CRC	2015-07-09 15:25:19	2017-10-03 16:47:12	163
CRC	2017-10-03 00:00:00	2023-10-02 00:00:00	ANCIEN	CRCE	Groupe CRCE	Groupe communiste républicain citoyen et écologiste	\N	du	CRCE	2017-10-03 00:00:00	2023-10-03 00:00:00	221
RTLI	2017-10-03 00:00:00	2017-10-24 00:00:00	ANCIEN	Les Indépendants	Groupe Les Indépendants - République et Territoires	Groupe Les Indépendants - République et Territoires	\N	du	RTLI	2017-10-03 16:49:27	2017-10-26 17:42:09	222
UC	2017-07-04 00:00:00	2026-10-04 00:00:00	ACTIF	UC	Groupe Union Centriste	Groupe Union Centriste	\N	du 	UC	2017-07-04 10:56:52	2026-10-05 15:50:49	201
SOC	2012-01-11 00:00:00	2015-06-10 00:00:00	ANCIEN	SOCR	Groupe socialiste et apparentés	Groupe socialiste et apparentés	\N	du	SOC	2015-07-01 18:41:56	2017-11-03 11:39:11	141
UMP	2015-06-02 00:00:00	\N	ACTIF	Les Républicains	Groupe Les Républicains	Groupe Les Républicains	\N	du	REPUBLICAINS	2015-06-02 13:50:47	2017-11-03 11:49:30	81
LREM	2017-06-28 00:00:00	2020-10-04 00:00:00	ANCIEN	LaREM	La République En Marche	La République En Marche	\N	de	LaREM	2017-06-29 09:48:06	2017-10-04 09:45:00	181
RTLI	2017-10-25 00:00:00	2020-10-04 00:00:00	ANCIEN	Les Indépendants	Groupe Les Indépendants - République et Territoires	Groupe Les Indépendants - République et Territoires	\N	du	RTLI	2023-10-11 16:10:03	2023-10-11 00:00:00	241
UC	2026-10-05 00:00:00	\N	ACTIF	UCI	Groupe Union Centriste et Indépendants	Groupe Union Centriste et Indépendants	\N	du 	UCI	2026-10-05 15:50:49	2026-10-05 15:50:49	362
UNT	2026-10-05 00:00:00	\N	ACTIF	UNT	Groupe Union Nationale pour les Territoires	Groupe Union Nationale pour les Territoires	\N	du	UNT	2026-10-05 15:36:44	2026-10-05 18:12:17	361
\.

COPY memcom (memcomid, orgcod, memcomdatdeb, memcomdatfin, temvalcod, evelic, evelib, evelil, eveobs, senmat, memcomtitsup, syscredat, sysmajdat) FROM stdin;
289	ECON	1986-10-02 00:00:00	2008-10-01 00:00:00	ANCIEN	\N	\N	\N	\N	86034E	\N	\N	\N
977	INITIATIVE	2003-02-12 00:00:00	2003-07-21 00:00:00	ANCIEN	\N	\N	\N	\N	86034E	\N	\N	\N
2134	SOCI	1986-10-06 00:00:00	1988-06-29 00:00:00	ANCIEN	\N	\N	\N	\N	86039K	\N	\N	\N
2135	AFCL	1988-06-29 00:00:00	1989-10-04 00:00:00	ANCIEN	\N	\N	\N	\N	86039K	\N	\N	\N
1916	20030715N6	2003-07-15 00:00:00	2004-04-30 00:00:00	ANCIEN	\N	\N	\N	\N	86034E	TITULAIRE	\N	\N
1805	20030515N2	2003-05-15 00:00:00	2004-04-30 00:00:00	ANCIEN	\N	\N	\N	\N	86034E	TITULAIRE	\N	\N
2429	NEANT	2004-10-01 00:00:00	2004-10-06 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	\N	\N
2483	NEANT	2004-10-01 00:00:00	2004-10-05 00:00:00	ANCIEN	\N	\N	\N	\N	86039K	\N	\N	\N
2532	ECON	2004-10-06 00:00:00	2012-02-20 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	\N	\N
2567	AFCL	2004-10-06 00:00:00	2008-10-06 00:00:00	ANCIEN	\N	\N	\N	\N	86039K	\N	\N	\N
3467	FORMATION	2007-01-10 00:00:00	2007-07-11 00:00:00	ANCIEN	\N	\N	\N	\N	86039K	\N	\N	\N
3668	SERVICE	2007-07-05 00:00:00	2007-08-02 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	\N	\N
4052	2008CMP9	2008-07-10 00:00:00	2008-07-17 00:00:00	ANCIEN	\N	\N	\N	\N	86034E	TITULAIRE	\N	\N
4009	ECONOMIE	2008-06-18 00:00:00	2008-07-23 00:00:00	ANCIEN	\N	\N	\N	\N	86034E	\N	\N	\N
4013	ECONOMIE	2008-06-18 00:00:00	2008-07-23 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	\N	\N
4064	2008CMP9	2008-07-10 00:00:00	2008-07-17 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	SUPPLEANT	\N	\N
4273	ETRD	2008-10-07 00:00:00	2009-07-21 00:00:00	ANCIEN	\N	\N	\N	\N	86039K	\N	\N	\N
3542	2007CMP3	2007-02-01 00:00:00	2007-02-13 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	TITULAIRE	\N	\N
3846	2007CMP16	2007-12-14 00:00:00	2007-12-18 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	SUPPLEANT	\N	\N
7708	2011CMP3	2011-02-10 00:00:00	\N	ACTIF	\N	\N	\N	\N	04033B	TITULAIRE	\N	\N
7127	2009CMP23	2009-12-22 00:00:00	\N	ACTIF	\N	\N	\N	\N	04033B	SUPPLEANT	\N	\N
6898	NEANT	2009-07-21 00:00:00	2010-01-07 00:00:00	ANCIEN	\N	\N	\N	\N	86039K	\N	\N	\N
6550	2009CMP1	2009-01-21 00:00:00	2009-01-28 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	TITULAIRE	\N	\N
4344	ETRD	2011-10-01 00:00:00	2014-09-30 00:00:00	ANCIEN	\N	\N	\N	\N	86034E	\N	\N	2014-10-01 19:54:29
67	ETRD	1989-10-04 00:00:00	2000-04-27 00:00:00	ANCIEN	\N	\N	\N	\N	86039K	\N	\N	\N
6455	COLLECTIVITE	2008-10-15 00:00:00	2009-06-30 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	\N	\N
6712	2009CMP6	2009-04-02 00:00:00	2009-04-07 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	SUPPLEANT	\N	\N
8086	ETRD	2011-10-01 00:00:00	2012-07-21 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	\N	\N	\N
7234	XYNTHIA	2010-03-30 00:00:00	2010-07-09 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	\N	\N
9311	DECE	2013-04-23 00:00:00	2013-10-09 00:00:00	ANCIEN	\N	\N	\N	\N	86034E	\N	\N	2013-12-16 10:30:09
8742	CAE	2012-02-21 00:00:00	2014-10-07 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	\N	2014-10-08 17:35:30
9716	GOUVERNANCE	2013-11-19 00:00:00	2014-09-30 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	2013-11-19 18:46:11	2014-11-18 11:50:10
9924	NEANT	2014-05-05 00:00:00	2014-05-06 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	\N	2014-05-05 10:40:21	2014-05-07 12:20:13
9930	ETRD	2014-05-07 00:00:00	2023-10-01 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	\N	2014-05-07 00:00:00	2017-10-04 00:00:00
9948	REGIONS	2014-06-18 00:00:00	2014-10-08 00:00:00	ANCIEN	\N	\N	\N	\N	86034E	\N	2014-06-19 09:34:24	2014-10-09 16:15:51
9953	REGIONS	2014-06-18 00:00:00	2015-01-17 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	2014-06-19 09:35:02	2015-04-07 18:21:18
10079	NEANT	2014-10-03 00:00:00	2023-10-01 00:00:00	ANCIEN	\N	\N	\N	\N	86034E	\N	2014-10-03 00:00:00	2017-10-05 00:00:00
10193	AFCL	2014-10-08 00:00:00	2023-10-01 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	2014-10-08 00:00:00	2017-10-04 00:00:00
11630	2015CMP19	2015-09-08 00:00:00	\N	ACTIF	\N	\N	\N	\N	04033B	TITULAIRE	\N	\N
12488	EGALITE	2016-07-07 00:00:00	2017-06-12 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	\N	2016-07-07 17:26:07	2017-06-12 11:07:18
12376	CITOYENNETE	2016-06-22 00:00:00	2016-07-07 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	\N	2016-06-22 16:29:30	2016-07-07 16:33:43
12168	TURQUIE	2016-04-27 00:00:00	2016-10-14 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	\N	2016-04-27 15:15:54	2017-06-12 11:08:26
13909	CHUTE	2018-02-07 00:00:00	2018-07-07 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	\N	2018-02-06 16:33:28	\N
14232	LPM	2018-06-19 00:00:00	2018-06-20 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	TITULAIRE	\N	\N
19818	CYBE	2024-06-05 00:00:00	2026-09-30 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	\N	\N	2026-09-30 15:09:04
19124	IMMI	2023-12-18 00:00:00	2023-12-19 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	TITULAIRE	\N	\N
18959	INEG	2021-06-24 00:00:00	2021-06-25 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	SUPPLEANT	\N	\N
18383	ETRD	2023-10-04 00:00:00	2026-09-30 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	\N	\N	2026-09-30 15:12:05
18007	NEANT	2023-10-02 00:00:00	2023-10-03 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	\N	\N	\N
18281	NEANT	2023-10-02 00:00:00	2023-10-03 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	\N	\N
18565	AFCL	2023-10-04 00:00:00	2024-10-21 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	\N	\N
20676	NEANT	2023-10-02 00:00:00	\N	ACTIF	\N	\N	\N	\N	86034E	\N	2025-06-03 11:00:19	2025-06-03 11:00:19
21813	LPMD	2026-06-22 00:00:00	2026-06-24 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	TITULAIRE	2026-06-22 15:10:12	2026-07-02 10:11:25
22050	NEANT	2026-10-01 00:00:00	2026-10-05 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	2026-09-27 19:26:47	2026-10-06 17:52:02
22947	CYBE	2026-10-21 00:00:00	\N	ACTIF	\N	\N	\N	\N	11027H	\N	2026-10-21 11:53:21	2026-10-27 16:55:25
22254	NEANT	2026-10-01 00:00:00	2026-10-05 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	\N	2026-09-30 15:12:05	2026-10-06 17:52:04
22630	ETRD	2026-10-06 00:00:00	\N	ACTIF	\N	\N	\N	\N	04033B	\N	2026-10-06 17:52:02	2026-10-06 17:52:02
22655	ETRD	2026-10-06 00:00:00	\N	ACTIF	\N	\N	\N	\N	11027H	\N	2026-10-06 17:52:04	2026-10-06 17:52:04
21375	NEANT	2025-11-13 00:00:00	2025-11-13 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	2025-11-12 15:21:55	2025-11-13 14:42:42
21379	AFCL	2025-11-14 00:00:00	2026-09-30 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	2025-11-13 14:42:42	2026-09-30 15:12:19
\.

COPY memgrppol (memgrppolid, grppolcod, typapppolcod, memgrppoldatdeb, memgrppoldatfin, temvalcod, evelic, evelib, evelil, eveobs, senmat, syscredat, sysmajdat) FROM stdin;
290	RPR	N	\N	2002-12-10 00:00:00	ANCIEN	\N	\N	\N	\N	86034E	\N	\N
715	UMP	N	2002-12-11 00:00:00	2004-04-30 00:00:00	ANCIEN	\N	\N	\N	\N	86034E	\N	\N
67	SOC	N	\N	2000-04-27 00:00:00	ANCIEN	\N	\N	\N	\N	86039K	\N	\N
2386	UMP	N	2012-11-07 00:00:00	2024-10-21 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	\N
1875	UMP	N	2007-10-01 00:00:00	2023-10-01 00:00:00	ANCIEN	\N	\N	\N	\N	86034E	\N	\N
2081	CRC	N	2008-11-28 00:00:00	2010-01-07 00:00:00	ANCIEN	\N	\N	\N	\N	86039K	\N	\N
2328	UMP	R	2011-10-01 00:00:00	2012-11-06 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	\N
2228	SOC	N	2011-10-01 00:00:00	2012-07-21 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	\N	\N
1702	SOC	N	2004-10-01 00:00:00	2008-11-27 00:00:00	ANCIEN	\N	\N	\N	\N	86039K	\N	\N
1776	NI	N	2004-10-05 00:00:00	2011-09-30 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	\N
1649	AUCUN	N	2004-10-01 00:00:00	2004-10-04 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	\N	\N
2421	SOC	N	2014-05-05 00:00:00	2023-10-01 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	2014-05-05 00:00:00	\N
3333	AUCUN	N	2023-10-02 00:00:00	2023-10-02 00:00:00	ANCIEN	\N	\N	\N	\N	11027H	\N	\N
3551	SOC	N	2023-10-03 00:00:00	\N	ACTIF	\N	\N	\N	\N	11027H	\N	\N
3507	UMP	N	2023-10-03 00:00:00	\N	ACTIF	\N	\N	\N	\N	86034E	\N	\N
3431	AUCUN	N	2023-10-02 00:00:00	2023-10-02 00:00:00	ANCIEN	\N	\N	\N	\N	86034E	\N	\N
3767	UMP	N	2025-11-13 00:00:00	2026-09-30 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	2025-11-12 15:22:34	2026-09-27 19:26:47
3899	AUCUN	N	2026-10-01 00:00:00	2026-10-04 00:00:00	ANCIEN	\N	\N	\N	\N	04033B	2026-09-27 19:26:47	2026-10-05 16:49:30
4157	UMP	N	2026-10-05 00:00:00	\N	ACTIF	\N	\N	\N	\N	04033B	2026-10-05 16:49:30	2026-10-05 16:59:27
\.

COPY sen (senmat, quacod, sennomuse, sennomtec, senprenomuse, sendatnai, sendatdec, etasencod, sendespro, pcscod, catprocod, sengrppolcodcou, sengrppolliccou, sentypappcou, sencomcodcou, sencomliccou, sencirnumcou, sencircou, senburliccou, senema, sennomusecap, senfem, sennumsie, syscredat, sysmajdat, sendaiurl) FROM stdin;
11027H	Mme	Conway-Mouret	CONWAY_MOURET_HELENE	Hélène	1960-09-13 00:00:00	\N	ACTIF	Professeure d'université	8000	61	SOC	SER	\N	ETRD	ETRD	1053	Français établis hors de France	\N	h.conway-mouret@senat.fr	CONWAY-MOURET	OUI	151	\N	2026-11-04 04:06:01	http://www.hatvp.fr/pages_nominatives/conway-mouret-helene.html
86034E	M.	Larcher	LARCHER GERARD	Gérard	1949-09-14 00:00:00	\N	ACTIF	Docteur vétérinaire	3115	46	UMP	Les Républicains	\N	NEANT	Aucune	895	Yvelines	Président du Sénat	g.larcher@senat.fr	LARCHER	NON	9	\N	2026-11-04 04:06:01	http://www.hatvp.fr/pages_nominatives/larcher-gerard.html
86039K	M.	Mélenchon	MELENCHON	Jean-Luc	1951-08-19 00:00:00	\N	ANCIEN	Cadre administratif	3300	73	CRC	CRCE	\N	NEANT	Aucune	265	Essonne	\N	bureau.melenchon@lepartidegauche.fr	MÉLENCHON	NON	\N	\N	2017-10-04 09:44:05	\N
04033B	M.	Retailleau	RETAILLEAU BRUNO	Bruno	1960-11-20 00:00:00	\N	ACTIF	Sans profession déclarée	7400	39	UMP	Les Républicains	\N	ETRD	ETRD	850	Vendée	\N	b.retailleau@senat.fr	RETAILLEAU	NON	58	\N	2026-11-04 04:06:01	http://www.hatvp.fr/pages_nominatives/retailleau-bruno.html
\.

COPY senbur (senburid, burcod, senburdatdeb, senburdatfin, senburrelint, senburrngele, temvalcod, evelic, evelib, evelil, eveobs, senmat, senburhon, syscredat, sysmajdat) FROM stdin;
290	VICPDTSEN	1997-01-15 00:00:00	1998-10-05 00:00:00	NON	1	ANCIEN	\N	\N	\N	\N	86034E	NON	\N	\N
375	VICPDTSEN	1998-10-06 00:00:00	2001-10-02 00:00:00	NON	2	ANCIEN	\N	\N	\N	\N	86034E	NON	\N	\N
67	AUCUNSEN	\N	2000-04-27 00:00:00	NON	1	ANCIEN	\N	\N	\N	\N	86039K	NON	\N	\N
1785	PDTSEN	2008-10-01 00:00:00	2011-09-30 00:00:00	NON	\N	ANCIEN	\N	\N	\N	\N	86034E	NON	\N	\N
1660	AUCUNSEN	2007-10-01 00:00:00	2008-09-30 00:00:00	NON	\N	ANCIEN	\N	\N	\N	\N	86034E	NON	\N	\N
1661	AUCUNSEN	1986-10-02 00:00:00	1989-10-03 00:00:00	NON	\N	ANCIEN	\N	\N	\N	\N	86034E	NON	\N	\N
1662	AUCUNSEN	1995-10-05 00:00:00	1997-01-14 00:00:00	NON	\N	ANCIEN	\N	\N	\N	\N	86034E	NON	\N	\N
1808	AUCUNSEN	2008-10-07 00:00:00	2010-01-07 00:00:00	NON	\N	ANCIEN	\N	\N	\N	\N	86039K	NON	\N	\N
1494	AUCUNSEN	2004-10-01 00:00:00	2024-10-21 00:00:00	NON	\N	ANCIEN	\N	\N	\N	\N	04033B	NON	\N	\N
1546	AUCUNSEN	2004-10-01 00:00:00	2004-10-05 00:00:00	NON	\N	ANCIEN	\N	\N	\N	\N	86039K	NON	\N	\N
580	AUCUNSEN	2001-10-03 00:00:00	2004-04-30 00:00:00	NON	\N	ANCIEN	\N	\N	\N	\N	86034E	NON	\N	\N
1464	SECRETSEN	1989-10-04 00:00:00	1995-10-04 00:00:00	NON	\N	ANCIEN	\N	\N	\N	\N	86034E	NON	\N	\N
1587	SECRETSEN	2004-10-06 00:00:00	2008-10-06 00:00:00	NON	\N	ANCIEN	\N	\N	\N	\N	86039K	NON	\N	\N
2060	AUCUNSEN	2011-10-01 00:00:00	2014-09-30 00:00:00	NON	\N	ANCIEN	\N	\N	\N	\N	86034E	NON	\N	2014-10-01 19:48:48
1971	AUCUNSEN	2011-10-01 00:00:00	2012-07-21 00:00:00	\N	\N	ANCIEN	\N	\N	\N	\N	11027H	\N	\N	\N
2497	VICPDTSEN	2018-11-01 00:00:00	2020-10-05 00:00:00	NON	8	ANCIEN	\N	\N	\N	\N	11027H	NON	\N	\N
2615	AUCUNSEN	2020-10-06 00:00:00	2023-10-01 00:00:00	NON	\N	ANCIEN	\N	\N	\N	\N	11027H	NON	\N	\N
2140	AUCUNSEN	2012-07-22 00:00:00	2018-10-31 00:00:00	\N	\N	ANCIEN	\N	\N	\N	\N	11027H	\N	2014-05-05 10:40:21	\N
2688	AUCUNSEN	2023-10-02 00:00:00	\N	\N	\N	ACTIF	\N	\N	\N	\N	11027H	\N	\N	\N
2841	PDTSEN	2023-10-02 00:00:00	2026-09-30 00:00:00	\N	1	ANCIEN	\N	\N	\N	\N	86034E	\N	\N	2026-09-30 09:40:25
2237	PDTSEN	2014-10-01 00:00:00	2023-10-01 00:00:00	NON	2	ANCIEN	\N	\N	\N	\N	86034E	NON	2014-10-01 00:00:00	2014-10-08 00:00:00
2920	AUCUNSEN	2025-11-13 00:00:00	2026-09-30 00:00:00	\N	\N	ANCIEN	\N	\N	\N	\N	04033B	\N	2025-11-12 15:21:55	2026-09-27 19:26:47
3028	AUCUNSEN	2026-10-01 00:00:00	\N	\N	\N	ACTIF	\N	\N	\N	\N	04033B	\N	2026-09-27 19:26:47	2026-09-27 19:26:47
3122	PDTSEN	2026-10-01 00:00:00	\N	\N	1	ACTIF	\N	\N	\N	\N	86034E	\N	2026-10-01 16:59:06	2026-10-01 16:59:25
\.

COPY typapppol (typapppolcod, typapppollib, typapppollic, typapppolnumtri, typapppollil, typapppollicfem, typapppollibfem, typapppollilfem, typapppollicplu, typapppollibplu, typapppollilplu, syscredat, sysmajdat) FROM stdin;
N	Membre	\N	1	Membre	\N	Membre	Membre	\N	Membres	Membres	\N	\N
R	Rattaché	-R	3	Membre rattaché 	-R	Rattachée	Membre rattachée	-R	Rattachés	Membres rattachés	\N	\N
A	Apparenté	-A	2	Membre apparenté	-A	Apparentée	Membre apparentée	-A	Apparentés	Membres apparentés	\N	\N
\.

COPY typorg (typorgcod, typorglib, typorglic, typorgnumtri, typorgurlsim, typorgurlcmp, typorglibplu, syscredat, sysmajdat) FROM stdin;
COMITE	Comité	Comité	18	\N	\N	Comités	\N	\N
AUCUN	(aucun)	(aucun)	0	\N	\N	(aucun)	\N	\N
AUTRES	Autres organismes	Autres organismes             	60	\N	\N	Autres organismes	\N	\N
COM	Commission permanente	Commission permanente	7	\N	\N	Commissions permanentes	\N	\N
DELEGA	Délégation	Délégation	16	\N	\N	Délégations	\N	\N
ETUDES	Groupe d'études	Groupes d'études	50	\N	\N	Groupes d'études	\N	\N
GRPSEN	Groupe interparlementaire d'amitié	Groupe d'amitié	50	\N	\N	Groupes interparlementaires d'amitiés	\N	\N
OFFICE	Office parlementaire	Office	16	\N	\N	Offices parlementaires	\N	\N
ORGEXT	Organisme Extra-Parlementaire	Extra-Parlementaire	27	\N	\N	Organismes Extra-Parlementaires	\N	\N
CONEUR	Conseil de l'Europe et UEO	Conseil de l'Europe et UEO	19	\N	\N	Conseil de l'Europe et UEO	\N	\N
GRPPOL	Groupe politique	Groupe politique	11	\N	\N	Groupes politiques	\N	\N
COUJUSREP	Cour de Justice de la République	Cour Justice République	14	\N	\N	Cour de Justice de la République	\N	\N
SENAT	Sénat	Sénat	40	\N	\N	Sénat	\N	\N
CONCST	Conseil Constitutionnel	Conseil Constitutionnel	6	\N	\N	Conseil Constitutionnel	\N	\N
BUR	Bureau du Sénat	Bureau du Sénat	1	\N	\N	Bureau du Sénat	\N	\N
MINIST	Ministère	Ministère	30	\N	\N	Ministères	\N	\N
COMENQ	Commission d'enquête	Commission d'enquête	25	/commission/enquete/index.html	\N	Commissions d'enquête	\N	\N
MISINF	Mission d'information	Mission d'information	43	/commission/missions/index.html	\N	Missions d'information	\N	\N
MISINFCOM	Mission commune d'information 	Mission commune d'information	42	/commission/missions/index.html	\N	Missions communes d'informations	\N	\N
PARPOL	Parti politique	Parti politique	51	\N	\N	Partis politiques	\N	\N
COMPOU	Commission de poursuite	Commission de poursuite	22	\N	\N	Commissions de poursuite	\N	\N
COMADHOC	Commission ad'hoc	Commission ad'hoc	23	\N	\N	Commissions ad'hoc	\N	\N
CMP	Commission mixte paritaire	CMP	27	/commission/cmp/index.html	\N	Commissions mixtes paritaires	\N	\N
ETUDESSCN	Section d'un groupe d'études	Section d'un groupe d'études	51	\N	\N	Sections d'un groupe d'études	\N	\N
OBS	Observatoire	Observatoire	17	\N	\N	Observatoires	\N	\N
COMEUR	Commission européenne	Commission européenne	8	\N	\N	Commission européenne	\N	\N
MISCOM	Mission commune	Mission commune	44	\N	\N	Missions communes	\N	\N
MECSS	Mission d'évaluation et de contrôle de la sécurité sociale	Mission d'évaluation de la SS	21	\N	\N	Mission d'évaluation et de contrôle de la sécurité sociale	\N	\N
GRPSENSCN	Section d'un Groupe interparlementaire d'amitié	Section d'un Groupe d'amitié	50	\N	\N	Sections d'un Groupe interparlementaire d'amitié	\N	\N
CSCE	Conférence sur la sécurité et la coopération en Europe	Conf. sécurité coop. Europe	20	\N	\N	Conférence sur la sécurité et la coopération en Europe	\N	\N
GRPPOLNI	Groupe politique des Non Inscrits	Groupe politique NI	12	\N	\N	Groupe politique des Non Inscrits	\N	\N
COMSPE	Commission spéciale	Commission spéciale	24	/commission/spec/index.html	\N	Commissions spéciales	\N	\N
HAUCOUJUS	Haute Cour de Justice	Haute Cour de Justice	13	\N	\N	Haute Cour de Justice	\N	\N
COMSPEAPU	Commission spéciale chargée du contrôle des comptes et de l'évaluation interne	Commission contrôle comptes	15	\N	\N	Commission spéciale chargée du contrôle des comptes et de l'évaluation interne	\N	\N
COMAPLEG	Commission en charge de l'application des lois	Commission application des lois	9	\N	\N	Commission en charge de l'application des lois	\N	\N
COMSENCOMMU	Commission du Sénat de la Communauté	Commission de la Communauté	55	\N	\N	\N	2015-02-10 14:18:09	\N
GRPLIAISON	Groupe de liaison	Groupe de liaison	\N	\N	\N	\N	\N	\N
\.

